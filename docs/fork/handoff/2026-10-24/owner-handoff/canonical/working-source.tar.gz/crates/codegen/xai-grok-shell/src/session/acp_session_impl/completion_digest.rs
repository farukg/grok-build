use super::*;
use xai_chat_state::{CompletionProjection, CompletionReceipt, StrictAppendError};
use xai_grok_tools::implementations::grok_build::task::types::{
    SubagentCompletionsRequest, SubagentEvent, completion_state_permits_wake,
};

impl SessionActor {
    pub(super) async fn project_subagent_wake_turn(
        &self,
        completion: &crate::session::CompletionWake,
        prompt_id: &str,
        fallback: String,
    ) -> Result<bool, xai_chat_state::CompletionProjectionError> {
        if self
            .tool_context
            .task_wake_suppressed
            .as_ref()
            .is_some_and(|gate| gate.get())
        {
            return Ok(false);
        }
        let state = self
            .persisted_completion_state()
            .await
            .map_err(StrictAppendError::NotCommitted)?;
        let receipts = &state.receipts;
        if receipts
            .iter()
            .any(|receipt| receipt.completion == completion.id)
        {
            return self
                .project_subagent_completion(completion, prompt_id, fallback)
                .await;
        }
        let Some(sender) = &self.tool_context.subagent_event_tx else {
            return self
                .project_subagent_completion(completion, prompt_id, fallback)
                .await;
        };
        let (respond_to, receive) = oneshot::channel();
        if sender
            .send(SubagentEvent::PeekCompletions(SubagentCompletionsRequest {
                parent_session_id: Some(self.session_id_string()),
                suppress_ids: receipts
                    .iter()
                    .map(|receipt| receipt.completion.clone())
                    .collect(),
                respond_to,
            }))
            .is_err()
        {
            return self
                .project_subagent_completion(completion, prompt_id, fallback)
                .await;
        }
        let summaries = receive.await.map_err(|_| {
            StrictAppendError::NotCommitted(std::io::Error::new(
                std::io::ErrorKind::BrokenPipe,
                "completion observation lost",
            ))
        })?;
        let summaries: Vec<_> = summaries
            .into_iter()
            .filter(|summary| completion_state_permits_wake(&summary.snapshot.status.state()))
            .collect();
        let bridge = self.agent.borrow().tool_bridge().clone();
        let mut text = if summaries.is_empty() {
            fallback
        } else {
            let contains_primary = summaries.iter().any(|summary| {
                summary.subagent_id() == completion.id.subagent_id
                    && summary.attempt_id == completion.id.attempt_id
            });
            let digest = xai_grok_tools::reminders::task_completion::format_between_turn_completion_reminder(&summaries, &bridge).await;
            let digest = reminder_text(&digest, self.reminder_wrapper_tag());
            if contains_primary {
                digest
            } else {
                format!("{fallback}\n\n{digest}")
            }
        };
        let summary_path =
            crate::session::persistence::session_dir(&self.session_info).join("summary.json");
        for summary in &summaries {
            let id = xai_chat_state::SubagentCompletionId {
                subagent_id: summary.subagent_id().to_owned(),
                attempt_id: summary.attempt_id.clone(),
            };
            if let Some(reference) = state.result_reference(&id, &summary_path) {
                text.push_str("\n\n");
                text.push_str(
                    &crate::session::completion_delivery::completion_reference_text(
                        &id, &reference,
                    ),
                );
            }
        }
        let mut projection =
            CompletionProjection::new(completion.id.clone(), prompt_id.to_owned(), text);
        projection.additional_receipts = summaries
            .into_iter()
            .filter(|summary| {
                summary.subagent_id() != completion.id.subagent_id
                    || summary.attempt_id != completion.id.attempt_id
            })
            .map(|summary| CompletionReceipt {
                completion: xai_chat_state::SubagentCompletionId {
                    subagent_id: summary.subagent_id().to_owned(),
                    attempt_id: summary.attempt_id,
                },
                prompt_id: prompt_id.to_owned(),
                parent_task: xai_chat_state::ParentTask::Unknown,
            })
            .collect();
        self.commit_subagent_projection(projection, prompt_id).await
    }
}
