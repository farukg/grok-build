#![cfg_attr(rustfmt, rustfmt::skip)]
use super::*;
use crate::session::SessionThread;
use crate::session::storage::StorageAdapter;
use super::completion_publication::{prepare_completion_admission, publish_committed_completion};
use super::completion_test_support::{
    CoordinatorFixture, DurableCompletionFixture, auto_wake_test_request,
    completion_data_with_initial_meta, pending_shell_completion_fixture,
};
use super::spawn::{
    inject_subagent_completed_prompt, join_worker_task, present_child_completion,
    should_auto_wake_subagent, will_wake_for, AutoWakeInputs, InjectParams,
};
use super::prompt_turn_receipt::{
    PromptTurnReceiptDisposition, PromptTurnSettlementInput,
    reduce_prompt_turn_settlement,
};
use super::attempt_runner::{
    OneTurnAttemptInput, canonical_total_tokens, record_subagent_usage,
    run_one_turn_attempt, usage_is_incomplete,
};
use super::handle_request::{
    CHILD_ACTOR_ACK_TIMEOUT, PARENT_ACK_TIMEOUT, TaskModelAdmissionError,
    admit_explicit_tool_model, agent_memory_scope_for_mode, child_actor_query,
    explicit_tool_model, mark_child_usage_not_applied_with_fallback,
    reparent_surviving_child_tasks, resolve_child_model, take_child_streaming_partial,
    take_child_turn_messages,
};
use crate::agent::remote_config::task_model_policy::TaskModelSelection;
use crate::test_support::lsp_runtime::{ctx_with_toggle, test_gateway_with_receiver};
use xai_grok_subagent_resolution::resolve_effective_overrides;
use xai_grok_tools::implementations::grok_build::task::coordinator::{
    ChildCompletion, CompletionDisposition,
};
use xai_grok_tools::implementations::grok_build::task::terminal_snapshot;
use xai_grok_tools::reminders::task_completion::INLINE_SUBAGENT_OUTPUT_BYTES;
fn test_snapshot(
    request: &SubagentRequest,
    result: &SubagentResult,
) -> SubagentSnapshot {
    terminal_snapshot(request, result, None, None, 0)
}
#[test]
fn v2_disables_legacy_agent_memory_scope() {
    let scope = Some(xai_grok_agent::config::MemoryScope::Project);
    assert_eq!(
            agent_memory_scope_for_mode(scope, crate::config::MemoryMode::V2),
            None
        );
    assert_eq!(
            agent_memory_scope_for_mode(scope, crate::config::MemoryMode::Legacy),
            scope
        );
}
#[test]
fn canonical_total_tokens_does_not_double_count_reasoning() {
    let totals = xai_chat_state::UsageTotals {
        input_tokens: 100,
        output_tokens: 40,
        reasoning_tokens: 25,
        ..Default::default()
    };
    assert_eq!(canonical_total_tokens(&totals), 140);
}
#[test]
fn cancellation_makes_an_otherwise_complete_usage_snapshot_incomplete() {
    assert!(usage_is_incomplete(false, true));
    assert!(!usage_is_incomplete(false, false));
    assert!(usage_is_incomplete(true, false));
}
#[tokio::test]
async fn usage_ack_precedes_terminal_presentation() {
    let mut ctx = ctx_with_toggle(HashMap::new());
    let (parent_cmd_tx, mut parent_cmd_rx) = mpsc::unbounded_channel();
    ctx.parent_cmd_tx = Some(parent_cmd_tx);
    let by_model = vec![(
            "test-model".to_string(),
            xai_chat_state::UsageTotals {
                input_tokens: 10,
                output_tokens: 4,
                ..Default::default()
            },
        )];
    let mut fold = Box::pin(
        record_subagent_usage(
            ctx.parent_cmd_tx.as_ref(),
            Some(by_model),
            Some("parent-prompt".to_string()),
            false,
        ),
    );
    let command = tokio::select! {
            command = parent_cmd_rx.recv() => command.expect("usage command"),
            result = &mut fold => panic!("usage fold returned before parent command: {result}"),
        };
    let SessionCommand::RecordSubagentUsage { respond_to, .. } = command else {
        panic!("expected RecordSubagentUsage");
    };
    assert!(
            tokio::time::timeout(std::time::Duration::ZERO, &mut fold)
                .await
                .is_err(),
            "child return must wait for usage acknowledgement"
        );
    assert!(parent_cmd_rx.try_recv().is_err());
    respond_to.send(()).expect("usage ack");
    assert!(fold.await);
    let (gateway, _gateway_rx) = test_gateway_with_receiver();
    let mut request = auto_wake_test_request("usage-order");
    request.run_in_background = false;
    let completion_data = ShellCompletionData::from_context(
        &ctx,
        None,
    );
    completion_data.mark_spawned_notification_emitted();
    let result = SubagentResult {
        state: SubagentState::Completed,
        subagent_id: "usage-order".to_string(),
        child_session_id: "usage-order".to_string(),
        ..Default::default()
    };
    let completion = ChildCompletion {
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
        snapshot: test_snapshot(&request, &result),
        request,
        result,
        completion_data,
        disposition: CompletionDisposition {
            foreground_delivered: true,
            backgrounded: false,
            waiter_delivered: false,
            explicitly_killed: false,
            reporting: xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Silent,
        },
    };
    let will_wake = will_wake_for(&completion);
    present_child_completion(completion, &gateway, will_wake);
    assert!(matches!(
            parent_cmd_rx.try_recv(),
            Ok(SessionCommand::SubagentCompletionPublished {
                notification: SessionNotification {
                    update: SessionUpdate::SubagentFinished { .. },
                    ..
                }
            })
        ));
}
/// Regression: reads of the child session's own actors (chat state, signals) must not park teardown when the child thread is synchronously blocked — the actors share its current-thread runtime — and must degrade to the cheap fallback in bounded time.
#[tokio::test(start_paused = true)]
async fn child_actor_query_is_bounded_when_the_actor_never_answers() {
    let tokens = tokio::time::timeout(
            20 * CHILD_ACTOR_ACK_TIMEOUT,
            child_actor_query("test_query", std::future::pending::<u64>(), 7),
        )
        .await
        .expect("child-actor queries must complete in bounded time");
    assert_eq!(tokens, 7, "a starved query must degrade to the fallback");
}
/// Regression: a wedged child actor that never answers `TakeTurnMessages`
/// must not park teardown ahead of the bounded upload set, and the
/// timed-out take must surface as the recorded miss, not an empty turn.
#[tokio::test(start_paused = true)]
async fn turn_message_take_is_bounded_and_records_the_wedge() {
    let (cmd_tx, _cmd_rx) = mpsc::unbounded_channel();
    let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(60);
    let taken = tokio::time::timeout(
            std::time::Duration::from_secs(3600),
            take_child_turn_messages(&cmd_tx, deadline),
        )
        .await
        .expect("the take must be bounded under a wedged child actor");
    assert!(matches!(
            taken,
            crate::upload::turn::TurnMessages::Missing(
                crate::upload::turn::MissingTurnMessages::TakeTimedOut
            )
        ));
}
/// The dead-actor takes — command channel closed, or responder dropped
/// without an answer — are recorded misses, not genuinely empty turns.
#[tokio::test(start_paused = true)]
async fn turn_message_take_records_the_miss_when_the_actor_is_gone() {
    use crate::upload::turn::{MissingTurnMessages, TurnMessages};
    let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(60);
    let (closed_tx, closed_rx) = mpsc::unbounded_channel();
    drop(closed_rx);
    let taken = take_child_turn_messages(&closed_tx, deadline).await;
    assert!(
            matches!(
                taken,
                TurnMessages::Missing(MissingTurnMessages::ChannelDropped)
            ),
            "a closed command channel must not pass for an empty turn"
        );
    let (cmd_tx, mut cmd_rx) = mpsc::unbounded_channel();
    let actor = tokio::spawn(async move {
        match cmd_rx.recv().await {
            Some(SessionCommand::TakeTurnMessages { respond_to }) => drop(respond_to),
            _ => panic!("expected TakeTurnMessages"),
        }
    });
    let taken = take_child_turn_messages(&cmd_tx, deadline).await;
    actor.await.expect("actor task");
    assert!(
            matches!(
                taken,
                TurnMessages::Missing(MissingTurnMessages::ChannelDropped)
            ),
            "a dropped responder must not pass for an empty turn"
        );
}
/// A real `SessionHandle` whose child-session actors never answer: the command channel is held open but unserviced and the signals actor is never run — the shape a tool synchronously blocking the child session thread leaves behind. The receiver and actor must stay alive so sends succeed but never get answered.
fn wedged_child_handle() -> (
    SessionHandle,
    mpsc::UnboundedReceiver<SessionCommand>,
    crate::session::signals::SessionSignalsActor,
) {
    let (cmd_tx, cmd_rx) = mpsc::unbounded_channel();
    let (persistence_tx, _persistence_rx) = mpsc::unbounded_channel();
    let (hunk_event_tx, _hunk_event_rx) = mpsc::unbounded_channel();
    let hunk_tracker_handle = xai_hunk_tracker::HunkTrackerActor::spawn(
        "test".to_string(),
        PathBuf::from("/tmp"),
        hunk_event_tx,
        xai_hunk_tracker::TrackingMode::AllDirty,
        CancellationToken::new(),
    );
    let (signals_handle, signals_actor) = crate::session::signals::SessionSignalsActor::new();
    let handle = SessionHandle {
        context_window_selection: Default::default(),
        cmd_tx,
        persistence_tx,
        registry_write_order: Default::default(),
        current_prompt_id: std::sync::Arc::new(std::sync::Mutex::new(None)),
        active_work: std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0)),
        pending_interactions: std::sync::Arc::new(std::sync::Mutex::new(HashMap::new())),
        info: SessionInfo {
            id: acp::SessionId::new("test"),
            cwd: "/tmp".to_string(),
        },
        max_turns: None,
        resolved_tool_overrides: std::sync::Arc::new(arc_swap::ArcSwapOption::empty()),
        spawn_snapshot: crate::session::SpawnSnapshot {
            applied_tool_overrides: None,
            memory_mode: None,
        },
        hunk_tracker_handle,
        chat_state_handle: xai_chat_state::ChatStateHandle::noop(),
        signals_handle,
        gateway_enabled: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(true)),
        emit_local_background_tasks: std::sync::Arc::new(
            std::sync::atomic::AtomicBool::new(true),
        ),
        client_caps: crate::session::notifications::SessionClientCaps::new(false, true),
        mcp_servers: Default::default(),
        initial_client_mcp_servers: Default::default(),
        display_cwd: None,
        feedback_manager: std::sync::Arc::new(
            crate::session::feedback_manager::FeedbackManager::local_only("test"),
        ),
        upload_queue: std::sync::Arc::new(std::sync::OnceLock::new()),
        upload_failures_since_success: std::sync::Arc::new(
            std::sync::atomic::AtomicU64::new(0),
        ),
        tool_context: crate::tools::ToolContext::new_local_context(
            xai_grok_paths::AbsPathBuf::new(PathBuf::from("/tmp")).unwrap(),
            std::sync::Arc::new(
                xai_grok_workspace::file_system::LocalFs::new(PathBuf::from("/tmp")),
            ),
            std::sync::Arc::new(crate::terminal::LocalTerminalRunner),
        ),
        model_id: acp::ModelId::new("test-model"),
        reasoning_effort: None,
        yolo_mode: false,
        origin_client: None,
        code_nav_enabled: false,
        ask_user_question_enabled: true,
        non_interactive: false,
        plan_mode: std::sync::Arc::new(
            parking_lot::Mutex::new(
                crate::session::plan_mode::PlanModeTracker::new(PathBuf::from("/tmp")),
            ),
        ),
        force_compact: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
        permission_handle: xai_grok_workspace::permission::PermissionHandle::allow_all(),
        attribution_callback: None,
        agent_name: "grok-build".to_string(),
        managed_mcp_proxy_base_url: String::new(),
        session_default_agent_profile: None,
        allowed_subagent_types: None,
        hook_registry: None,
        workspace_ops: xai_grok_workspace::WorkspaceOps::for_test(),
        terminal_backend: None,
        tools_notification_handle: None,
        scheduler_handle: None,
    };
    (handle, cmd_rx, signals_actor)
}
/// Regression: a cancel that cannot read the child's signals (wedged actor) must fail closed — "no answer" is not "no work done" — so the usage fold marks the parent's bill incomplete instead of folding a clean ledger over the cancelled turn's in-flight sampling.
#[tokio::test(start_paused = true)]
async fn cancelled_attempt_fails_closed_when_the_signals_read_never_answers() {
    let (child_handle, _cmd_rx, _signals_actor) = wedged_child_handle();
    let cancel_token = CancellationToken::new();
    cancel_token.cancel();
    let request = auto_wake_test_request("cancel-wedge");
    let outcome = tokio::time::timeout(
            20 * CHILD_ACTOR_ACK_TIMEOUT,
            run_one_turn_attempt(OneTurnAttemptInput {
                child_handle: &child_handle,
                request: &request,
                worktree_path: None,
                task_prompt_text: "task",
                prompt_id: uuid::Uuid::now_v7().to_string(),
                inherited_tool_overrides: None,
                gcs_bucket_url: None,
                gcs_upload_method: None,
                turn_number: 0,
                cancel_token,
                child_run_started_at: std::time::Instant::now(),
                prompt_admitted: tokio::sync::oneshot::channel().0,
                initial_attempt_behavior: InitialAttemptBehavior::Normal,
            }),
        )
        .await
        .expect(
            "a cancelled attempt must complete in bounded time under a wedged child",
        );
    assert!(outcome.result.is_interrupted());
    assert!(
            outcome.cancellation_may_hide_usage,
            "an unanswered signals read must not pass for 'no work done'"
        );
}
/// Regression: a wedged child actor must not park teardown on the
/// streaming-capture take; the capture is skipped in bounded time.
#[tokio::test(start_paused = true)]
async fn streaming_partial_take_is_bounded_when_the_child_actor_is_wedged() {
    let (cmd_tx, _cmd_rx) = mpsc::unbounded_channel();
    let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(60);
    let capture = tokio::time::timeout(
            std::time::Duration::from_secs(3600),
            take_child_streaming_partial(
                &cmd_tx,
                deadline,
                "prompt-1".into(),
                false,
                None,
            ),
        )
        .await
        .expect("the streaming take must be bounded under a wedged child actor");
    assert!(capture.is_none(), "a timed-out take skips the capture");
}
/// Regression: the resolved-model read for turn_result.json must degrade
/// to the configured model id in bounded time under a wedged child actor.
#[tokio::test(start_paused = true)]
async fn resolved_model_read_is_bounded_and_falls_back_to_configured() {
    let (cmd_tx, _cmd_rx) = mpsc::unbounded_channel();
    let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(60);
    let resolved = tokio::time::timeout(
            std::time::Duration::from_secs(3600),
            resolve_child_model(&cmd_tx, deadline, Some("configured-model".into())),
        )
        .await
        .expect("the model read must be bounded under a wedged child actor");
    assert_eq!(resolved.as_deref(), Some("configured-model"));
}
/// Regression: a completed child's usage fold must not park forever behind
/// a parent actor that never services `cmd_rx`; that leaked the child's
/// session thread, fs watchers, and fds.
#[tokio::test(start_paused = true)]
async fn usage_fold_is_bounded_when_parent_never_services_commands() {
    let (parent_cmd_tx, _parent_cmd_rx) = mpsc::unbounded_channel();
    let by_model = vec![(
            "test-model".to_string(),
            xai_chat_state::UsageTotals {
                input_tokens: 10,
                ..Default::default()
            },
        )];
    let folded = tokio::time::timeout(
            20 * PARENT_ACK_TIMEOUT,
            record_subagent_usage(
                Some(&parent_cmd_tx),
                Some(by_model),
                Some("parent-prompt".to_string()),
                false,
            ),
        )
        .await
        .expect("usage fold must complete in bounded time under a starved parent");
    assert!(
            !folded,
            "an unacked fold must report a miss so the sticky fallback marks the bill incomplete"
        );
}
/// Regression: when the parent never acks, the usage-not-applied mark must
/// fall through to the coordinator's report-level sticky in bounded time.
#[tokio::test(start_paused = true)]
async fn usage_not_applied_mark_falls_back_to_coordinator_when_parent_is_starved() {
    let (parent_cmd_tx, _parent_cmd_rx) = mpsc::unbounded_channel();
    let (event_tx, mut event_rx) = mpsc::unbounded_channel();
    let mark = mark_child_usage_not_applied_with_fallback(
        Some(&parent_cmd_tx),
        &event_tx,
        "parent-sess",
        Some("prompt-1".to_string()),
    );
    let coordinator = async {
        let event = event_rx.recv().await.expect("coordinator fallback event");
        let SubagentEvent::MarkUsageNotApplied(req) = event else {
            panic!("expected MarkUsageNotApplied");
        };
        assert_eq!(req.parent_session_id, "parent-sess");
        assert_eq!(req.prompt_id, "prompt-1");
        let _ = req.respond_to.send(());
    };
    tokio::time::timeout(
            20 * PARENT_ACK_TIMEOUT,
            async { tokio::join!(mark, coordinator) },
        )
        .await
        .expect(
            "usage-not-applied mark must complete in bounded time under a starved parent",
        );
}
/// A parent that acks the mark in time owns it: the coordinator fallback
/// must not fire (a double mark would double-report the sticky).
#[tokio::test]
async fn usage_not_applied_mark_skips_coordinator_when_parent_acks() {
    let (parent_cmd_tx, mut parent_cmd_rx) = mpsc::unbounded_channel();
    let (event_tx, mut event_rx) = mpsc::unbounded_channel();
    let mark = mark_child_usage_not_applied_with_fallback(
        Some(&parent_cmd_tx),
        &event_tx,
        "parent-sess",
        Some("prompt-1".to_string()),
    );
    let parent = async {
        match parent_cmd_rx.recv().await.expect("parent mark command") {
            SessionCommand::MarkSubagentUsageNotApplied { respond_to, .. } => {
                let _ = respond_to.send(());
            }
            _ => panic!("expected MarkSubagentUsageNotApplied"),
        }
    };
    tokio::join!(mark, parent);
    assert!(
            event_rx.try_recv().is_err(),
            "a parent-acked mark must not also mark the coordinator sticky"
        );
}
/// With no parent command channel the mark goes straight to the
/// coordinator's report-level sticky.
#[tokio::test]
async fn usage_not_applied_mark_goes_straight_to_coordinator_without_parent() {
    let (event_tx, mut event_rx) = mpsc::unbounded_channel();
    let mark = mark_child_usage_not_applied_with_fallback(
        None,
        &event_tx,
        "parent-sess",
        Some("prompt-1".to_string()),
    );
    let coordinator = async {
        let event = event_rx.recv().await.expect("coordinator fallback event");
        let SubagentEvent::MarkUsageNotApplied(req) = event else {
            panic!("expected MarkUsageNotApplied");
        };
        assert_eq!(req.parent_session_id, "parent-sess");
        assert_eq!(req.prompt_id, "prompt-1");
        let _ = req.respond_to.send(());
    };
    tokio::join!(mark, coordinator);
}
/// Terminal backend whose actor never answers — models a parent terminal
/// actor starved by a busy turn.
struct StarvedTerminal;
#[async_trait::async_trait]
impl xai_grok_tools::computer::types::TerminalBackend for StarvedTerminal {
    async fn run(
        &self,
        _request: xai_grok_tools::computer::types::TerminalRunRequest,
    ) -> Result<
        xai_grok_tools::computer::types::TerminalRunResult,
        xai_grok_tools::computer::types::ComputerError,
    > {
        std::future::pending().await
    }
    async fn run_background(
        &self,
        _request: xai_grok_tools::computer::types::TerminalRunRequest,
    ) -> Result<
        xai_grok_tools::computer::types::BackgroundHandle,
        xai_grok_tools::computer::types::ComputerError,
    > {
        std::future::pending().await
    }
    async fn get_task(
        &self,
        _task_id: &str,
    ) -> Option<xai_grok_tools::computer::types::TaskSnapshot> {
        std::future::pending().await
    }
    async fn kill_task(
        &self,
        _task_id: &str,
    ) -> xai_grok_tools::computer::types::KillOutcome {
        std::future::pending().await
    }
    async fn wait_for_completion(
        &self,
        _task_id: &str,
        _timeout: Option<std::time::Duration>,
    ) -> Option<xai_grok_tools::computer::types::TaskSnapshot> {
        std::future::pending().await
    }
    async fn list_tasks(&self) -> Vec<xai_grok_tools::computer::types::TaskSnapshot> {
        std::future::pending().await
    }
    async fn reparent_notifications(
        &self,
        _old_owner_session_id: &str,
        _new_owner_session_id: &str,
        _new_handle: xai_grok_tools::notification::types::ToolNotificationHandle,
        _backend_weak: std::sync::Weak<
            dyn xai_grok_tools::computer::types::TerminalBackend,
        >,
    ) {
        std::future::pending().await
    }
}
/// Regression: the goal-task snapshot and the notification reparent must not park a completed child before Shutdown when the parent terminal actor never answers; a timed-out snapshot skips goal-turn tagging instead of sending a partial record.
#[tokio::test(start_paused = true)]
async fn reparent_is_bounded_when_terminal_actor_never_answers() {
    let parent_tb: std::sync::Arc<
        dyn xai_grok_tools::computer::types::TerminalBackend,
    > = std::sync::Arc::new(StarvedTerminal);
    let notif_handle = xai_grok_tools::notification::types::ToolNotificationHandle::noop();
    let (cmd_tx, mut cmd_rx) = mpsc::unbounded_channel();
    tokio::time::timeout(
            20 * PARENT_ACK_TIMEOUT,
            reparent_surviving_child_tasks(
                &parent_tb,
                &notif_handle,
                Some(&cmd_tx),
                "child-sess",
                "parent-sess",
                false,
            ),
        )
        .await
        .expect("teardown must reach Shutdown under a starved terminal actor");
    assert!(
            cmd_rx.try_recv().is_err(),
            "a timed-out list_tasks must not record goal-turn task ids"
        );
}
/// Invariant: resolving a subagent applies the parent session's `--tools`/`--disallowed-tools`/`--permission-mode` — driven through `resolve_agent_definition` so the spawn path can't skip them.
/// Invariant: resolving a subagent applies the parent session's `--tools`/`--disallowed-tools`/`--permission-mode`.
/// They flow through `resolve_agent_definition` so the spawn path can't skip them.
#[tokio::test]
async fn subagent_inherits_session_cli_overrides() {
    use xai_grok_agent::config::{AgentDefinition, PermissionMode};
    let mut probe = AgentDefinition::general_purpose();
    probe.name = "session-override-probe".into();
    probe.permission_mode = PermissionMode::Plan;
    probe.disallowed_tools = vec!["write".into()];
    let mut config = crate::agent::config::Config::default();
    config.cli_agents = vec![probe];
    config.cli_agent_overrides = crate::agent::config::CliAgentOverrides {
        tools: Some(vec!["read_file".into(), "grep".into()]),
        disallowed_tools: Some(vec!["web_search".into(), "write".into()]),
        permission_mode: Some(PermissionMode::AcceptEdits),
        ..Default::default()
    };
    let mut ctx = ctx_with_toggle(std::collections::HashMap::new());
    ctx.agent_config = Some(config);
    let def = resolve_agent_definition("session-override-probe", &ctx)
        .expect("cli agent resolves");
    assert_eq!(
            def.session_tools_allowlist.as_deref(),
            Some(["read_file".into(), "grep".into()].as_slice())
        );
    assert_eq!(
            def.session_tools_denylist.as_deref(),
            Some(["web_search".into(), "write".into()].as_slice())
        );
    assert_eq!(def.disallowed_tools, vec!["write"]);
    assert_eq!(def.permission_mode, PermissionMode::AcceptEdits);
}
#[test]
fn subagent_bypass_permission_mode_gated_by_policy_pin() {
    use xai_grok_agent::config::PermissionMode;
    const PIN: &str = xai_grok_workspace::permission::resolution::YoloPinReason::DisableBypassPermissionsMode
        .message();
    assert_eq!(
            resolve_subagent_permission_mode(PermissionMode::BypassPermissions, false, None),
            PermissionMode::BypassPermissions,
        );
    assert_eq!(
            resolve_subagent_permission_mode(PermissionMode::BypassPermissions, false, Some(PIN)),
            PermissionMode::Default,
        );
    assert_eq!(
            resolve_subagent_permission_mode(PermissionMode::Plan, false, Some(PIN)),
            PermissionMode::Plan,
        );
    assert_eq!(
            resolve_subagent_permission_mode(PermissionMode::BypassPermissions, true, None),
            PermissionMode::Default,
        );
}
/// The subagent emitter's persist hop (`SessionCommand`) and live broadcast must carry the SAME `eventId`, minted before the fork.
/// Divergent or missing ids degrade cursor reconnects to full replays or re-applied lines.
#[tokio::test]
async fn emit_subagent_notification_stamps_one_event_id_on_both_paths() {
    use crate::test_support::lsp_runtime::test_gateway_with_receiver;
    let (gateway, mut gateway_rx) = test_gateway_with_receiver();
    let (cmd_tx, mut cmd_rx) = mpsc::unbounded_channel();
    emit_subagent_notification(
        &gateway,
        "parent-sess",
        SessionUpdate::SubagentFinished {
            attempt_id: None,
            subagent_id: "sa-1".into(),
            child_session_id: "child-1".into(),
            status: "completed".into(),
            error: None,
            tool_calls: 0,
            turns: 0,
            duration_ms: 5,
            tokens_used: 0,
            output: None,
            will_wake: false,
        },
        Some(&cmd_tx),
    );
    let persisted_id = match cmd_rx.try_recv().expect("persist hop must fire") {
        SessionCommand::XaiSessionNotification { notification } => {
            notification
                .meta
                .as_ref()
                .and_then(|m| m.get("eventId"))
                .and_then(|v| v.as_str())
                .expect("persisted subagent lines must carry an eventId")
                .to_string()
        }
        _ => panic!("expected XaiSessionNotification"),
    };
    assert!(persisted_id.starts_with("parent-sess-"));
    let broadcast_id = match gateway_rx.try_recv().expect("broadcast must fire") {
        xai_acp_lib::AcpClientMessage::ExtNotification(args) => {
            let params: serde_json::Value = serde_json::from_str(
                    args.request.params.get(),
                )
                .unwrap();
            params
                .get("_meta")
                .and_then(|m| m.get("eventId"))
                .and_then(|v| v.as_str())
                .expect("broadcast must carry eventId")
                .to_string()
        }
        _ => panic!("expected ExtNotification"),
    };
    assert_eq!(persisted_id, broadcast_id);
}
#[test]
fn subagent_max_turns_definition_wins_else_inherits_parent() {
    assert_eq!(super::resolve_subagent_max_turns(Some(2), Some(5)), Some(2));
    assert_eq!(super::resolve_subagent_max_turns(None, Some(5)), Some(5));
}
#[test]
fn resume_worktree_action_covers_three_outcomes() {
    use super::{ResumeWorktreeAction, resume_worktree_action};
    assert_eq!(
            resume_worktree_action(true, Some("refs/grok/subagents/x")),
            ResumeWorktreeAction::Rehydrate
        );
    assert_eq!(
            resume_worktree_action(false, Some("refs/grok/subagents/x")),
            ResumeWorktreeAction::Rehydrate
        );
    assert_eq!(
            resume_worktree_action(true, None),
            ResumeWorktreeAction::Reuse
        );
    assert_eq!(
            resume_worktree_action(false, None),
            ResumeWorktreeAction::Shared
        );
}
#[tokio::test(flavor = "current_thread")]
async fn completion_errors_admit_parent_wake_but_explicit_stop_stays_silent() {
    use xai_tool_types::InterruptionCause;
    use xai_grok_tools::implementations::grok_build::task::backend::SubagentBackend;
    tokio::task::LocalSet::new().run_until(async {
    for (state, wake, status, error) in [
        (SubagentState::Completed, true, SubagentMetaStatus::Completed, None),
        (SubagentState::Failed { message: "upload rejected".into() }, true, SubagentMetaStatus::Failed, Some("upload rejected")),
        (SubagentState::Interrupted { cause: InterruptionCause::Error { message: "receipt actor failed".into() } }, true, SubagentMetaStatus::Cancelled, Some("receipt actor failed")),
        (SubagentState::Interrupted { cause: InterruptionCause::ExplicitStop { actor: xai_tool_types::SubagentActor::Human } }, false, SubagentMetaStatus::Cancelled, Some("Subagent was stopped by human user.")),
    ] {
        let mut ctx = ctx_with_toggle(HashMap::new());
        ctx.task_output_tool_name = "get_command_or_subagent_output".into();
        let mut fixture = DurableCompletionFixture::new(&mut ctx).await;
        let mut request = auto_wake_test_request("wake-error-class");
        request.parent_session_id = ctx.parent_session_id.clone();
        let meta_dir = fixture.directory.path().join("subagents").join(&request.id);
        let parent = ctx.parent_cmd_tx.as_ref().expect("parent transport").clone();
        let (gateway, _gateway_rx) = test_gateway_with_receiver();
        let mut coordinator = CoordinatorFixture::new(ctx, state.clone(), meta_dir.clone(), gateway);
        let backend = coordinator.backend.clone();
        let spawned = tokio::task::spawn_local(async move { backend.spawn(request, None, None).await });
        let completion = tokio::time::timeout(std::time::Duration::from_secs(5), coordinator.classified.recv())
            .await.expect("real coordinator classification").expect("classified completion");
        let attempt = completion.attempt_id.clone();
        assert_eq!(completion.disposition.reporting,
            if wake { xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Reportable }
            else { xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Silent });
        assert_eq!(will_wake_for(&completion), wake);
        assert!(matches!(
            tokio::time::timeout(std::time::Duration::from_secs(5), coordinator.visible.recv())
                .await.expect("real publication callback").expect("publication outcome"),
            xai_grok_tools::implementations::grok_build::task::coordinator::TerminalVisibilityResult::Published
        ));
        let completed = spawned.await.expect("coordinator spawn task").expect("native terminal result");
        assert_eq!(completed.state, state);
        let (respond_to, _response) = oneshot::channel();
        parent.send(SessionCommand::GetToolOverrides { respond_to }).unwrap();
        let mut prompts = Vec::new();
        tokio::time::timeout(std::time::Duration::from_secs(5), async {
            loop {
                let command = fixture.observed.recv().await.expect("FIFO parent observation");
                if let SessionCommand::SubagentCompletionWake { text, .. } = command {
                    prompts.push(text);
                } else {
                    assert!(matches!(command, SessionCommand::GetToolOverrides { .. }));
                    break;
                }
            }
        }).await.expect("parent observation barrier");
        assert_eq!(prompts.len(), usize::from(wake));
        if wake {
            assert!(prompts[0].contains("wake-error-class"));
        }
        let metadata: SubagentMeta = serde_json::from_slice(&std::fs::read(meta_dir.join("meta.json")).unwrap()).unwrap();
        assert_eq!(metadata.status, status);
        assert_eq!(metadata.error.as_deref(), error);
        assert!(metadata.completed_at.is_some());
        let updates = fixture.storage.load_session(&fixture.info).await.expect("actual persisted outcome").updates;
        let notifications: Vec<_> = updates.iter().filter_map(|update| match update {
            crate::session::storage::SessionUpdate::Xai(notification) => matches!(&notification.update,
                SessionUpdate::SubagentFinished { subagent_id, .. } if subagent_id == "wake-error-class").then_some(notification),
            crate::session::storage::SessionUpdate::Acp(_) => None,
        }).collect();
        assert_eq!(notifications.len(), 1);
        let notification = notifications[0];
        let fact: crate::session::completion_delivery::SubagentCompletionFact = serde_json::from_value(
            notification.meta.as_ref().unwrap()["subagentCompletion"].clone()
        ).unwrap();
        assert_eq!(fact.state, state);
        assert_eq!(fact.id.attempt_id, attempt);
        assert!(matches!(&notification.update, SessionUpdate::SubagentFinished { will_wake, .. } if *will_wake == wake));
    }
    }).await;
}

#[test]
fn should_auto_wake_subagent_truth_table() {
    let wakeable = AutoWakeInputs {
        cancelled: false,
        auto_wake_enabled: true,
        explicitly_killed: false,
        parent_channel_open: true,
    };
    assert!(should_auto_wake_subagent(wakeable));
    let suppressed = [
        AutoWakeInputs {
            cancelled: true,
            ..wakeable
        },
        AutoWakeInputs {
            auto_wake_enabled: false,
            ..wakeable
        },
        AutoWakeInputs {
            explicitly_killed: true,
            ..wakeable
        },
        AutoWakeInputs {
            parent_channel_open: false,
            ..wakeable
        },
    ];
    for (i, inputs) in suppressed.into_iter().enumerate() {
        assert!(!should_auto_wake_subagent(inputs), "suppressed case {i}");
    }
}
fn prompt_text(blocks: &[acp::ContentBlock]) -> String {
    blocks
        .iter()
        .filter_map(|block| match block {
            acp::ContentBlock::Text(text) => Some(text.text.as_str()),
            _ => None,
        })
        .collect()
}
#[test]
fn completed_followup_wakes_parent_with_exactly_one_prompt() {
    let (gateway, _gateway_rx) = test_gateway_with_receiver();
    let (parent_cmd_tx, mut parent_cmd_rx) = mpsc::unbounded_channel();
    let folded = reduce_prompt_turn_settlement(PromptTurnSettlementInput {
        result: SubagentResult {
            subagent_id: "sa-followup".into(),
            child_session_id: "sa-followup".into(),
            turns: 2,
            ..Default::default()
        },
        disposition: PromptTurnReceiptDisposition::Completed,
        final_receipt: Some(Ok(crate::session::commands::ok_end_turn(1, None))),
        final_text: "follow-up result".to_string(),
        was_cancelled: false,
    });
    assert!(folded.result.success());
    assert!(!folded.result.is_interrupted());
    let request = auto_wake_test_request("sa-followup");
    let completion = ChildCompletion {
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
        snapshot: test_snapshot(&request, &folded.result),
        request,
        result: folded.result,
        completion_data: ShellCompletionData {
            auto_wake_enabled: true,
            parent_cmd_tx: Some(parent_cmd_tx),
            task_output_tool_name: "get_command_or_subagent_output".into(),
            ..Default::default()
        },
        disposition: CompletionDisposition {
            foreground_delivered: false,
            backgrounded: true,
            waiter_delivered: false,
            explicitly_killed: false,
            reporting: xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Reportable,
        },
    };
    let will_wake = will_wake_for(&completion);
    assert!(will_wake);
    present_child_completion(completion, &gateway, will_wake);
    let mut finish_count = 0;
    let mut prompt_count = 0;
    while let Ok(command) = parent_cmd_rx.try_recv() {
        match command {
            SessionCommand::SubagentCompletionPublished {
                notification: SessionNotification {
                    update: SessionUpdate::SubagentFinished {
                        status,
                        turns,
                        will_wake,
                        ..
                    },
                    ..
                },
            } => {
                assert_eq!((status.as_str(), turns, will_wake), ("completed", 2, true));
                finish_count += 1;
            }
            SessionCommand::SubagentCompletionWake { prompt_id, .. } => {
                assert!(prompt_id.starts_with("subagent-completed-"));
                prompt_count += 1;
            }
            _ => panic!("unexpected parent command"),
        }
    }
    assert_eq!((finish_count, prompt_count), (1, 1));
}
#[tokio::test(flavor = "current_thread")]
async fn inject_subagent_completed_prompt_sends_prompt() {
    tokio::task::LocalSet::new().run_until(async {
        let receiver = crate::session::acp_session::support::completion_wake_receiver_fixture().await;
        let (cmd_tx, mut cmd_rx) = mpsc::unbounded_channel::<SessionCommand>();
        let mut request = auto_wake_test_request("sa-1");
        request.runtime_overrides.loop_task_id = Some("loop-123".into());
        let result = SubagentResult {
            state: SubagentState::Completed,
            output: std::sync::Arc::from("PING"),
            subagent_id: "sa-1".into(),
            child_session_id: "sa-1".into(),
            ..Default::default()
        };
        inject_subagent_completed_prompt(InjectParams {
            attempt_id: &xai_message_delivery_core::AttemptId::mint(1),
            subagent_id: "sa-1",
            result: &result,
            request: &request,
            snapshot: &test_snapshot(&request, &result),
            parent_cmd_tx: Some(&cmd_tx),
            task_output_tool_name: "get_command_or_subagent_output",
            scheduler_delete_tool_name: Some("renamed_scheduler_delete"),
            scheduler_create_tool_name: Some("renamed_scheduler_create"),
            synthetic_trace_tx: &None,
        });
        let command = cmd_rx.try_recv().expect("expected synthetic completion wake");
        let SessionCommand::SubagentCompletionWake { ref prompt_id, .. } = command else {
            panic!("expected SessionCommand::SubagentCompletionWake");
        };
        assert!(prompt_id.starts_with("subagent-completed-"));
        let prompt_id = prompt_id.clone();
        receiver.sender.send(command).expect("real receiver must be open");
        let (respond_to, settled) = oneshot::channel();
        receiver.sender.send(SessionCommand::GetToolOverrides { respond_to }).expect("input FIFO barrier");
        tokio::time::timeout(std::time::Duration::from_secs(5), settled).await
            .expect("typed completion queue FIFO").expect("actual receiver acknowledgement");
        let (verbatim, prompt_blocks) = {
            let state = receiver.actor.state.lock().await;
            let input = state.pending_inputs.iter().find(|input| input.prompt_id == prompt_id)
                .expect("typed completion must reach the real input queue");
            (input.verbatim, input.prompt_blocks.clone())
        };
        assert!(verbatim);
        let prompt = prompt_text(&prompt_blocks);
        let block = prompt
            .find("\n=== Output ===\nPING\n\n<subagent_meta>")
            .expect("inlined task output");
        let cleanup = prompt
            .find("If this schedule is no longer relevant")
            .expect("cleanup hint");
        assert!(block < cleanup, "task output precedes the hints: {prompt}");
        assert!(prompt.contains(
                "Check the subagent output using get_command_or_subagent_output(\"sa-1\")"
            ));
        assert!(prompt.contains("renamed_scheduler_delete(\"loop-123\")"));
        assert!(prompt.contains(
                "renamed_scheduler_create(new_prompt, interval, \"loop-123\")"
            ));
        assert!(!prompt.contains("update it with scheduler_create("));
    }).await;
}
#[test]
fn inject_subagent_completed_prompt_copies_capped_task_output() {
    let (cmd_tx, mut cmd_rx) = mpsc::unbounded_channel::<SessionCommand>();
    let output = "x".repeat(20_000);
    let request = auto_wake_test_request("sa-1");
    let result = SubagentResult {
        state: SubagentState::Completed,
        output: std::sync::Arc::from(output.as_str()),
        subagent_id: "sa-1".into(),
        child_session_id: "sa-1".into(),
        ..Default::default()
    };
    inject_subagent_completed_prompt(InjectParams {
        attempt_id: &xai_message_delivery_core::AttemptId::mint(1),
        subagent_id: "sa-1",
        result: &result,
        request: &request,
        snapshot: &test_snapshot(&request, &result),
        parent_cmd_tx: Some(&cmd_tx),
        task_output_tool_name: "get_command_or_subagent_output",
        scheduler_delete_tool_name: None,
        scheduler_create_tool_name: None,
        synthetic_trace_tx: &None,
    });
    let SessionCommand::SubagentCompletionWake { text: prompt, .. } = cmd_rx
        .try_recv()
        .expect("expected synthetic completion wake") else {
        panic!("expected SessionCommand::SubagentCompletionWake");
    };
    assert!(prompt.contains("\n=== Task sa-1 ===\n"), "{prompt}");
    assert!(
            prompt.contains(&format!(
                "\n[output truncated: {INLINE_SUBAGENT_OUTPUT_BYTES} of 20000 bytes shown]\n\
                 Use get_command_or_subagent_output(\"sa-1\") to see the full output.\n\n\
                 <subagent_meta>id=sa-1, "
            )),
            "{}",
            prompt
                .len()
                .checked_sub(400)
                .and_then(|i| prompt.get(i..))
                .unwrap_or(prompt.as_str())
        );
    let len = prompt.len();
    let threshold = crate::session::acp_session::LARGE_PROMPT_THRESHOLD;
    assert!(len < threshold, "wake prompt was {len} bytes, threshold {threshold}");
}
#[test]
fn inject_subagent_completed_prompt_omits_cleanup_without_loop_task() {
    let (cmd_tx, mut cmd_rx) = mpsc::unbounded_channel::<SessionCommand>();
    let request = auto_wake_test_request("sa-no-loop");
    let result = SubagentResult {
        state: SubagentState::Completed,
        subagent_id: "sa-no-loop".into(),
        child_session_id: "sa-no-loop".into(),
        ..Default::default()
    };
    inject_subagent_completed_prompt(InjectParams {
        attempt_id: &xai_message_delivery_core::AttemptId::mint(1),
        subagent_id: "sa-no-loop",
        result: &result,
        request: &request,
        snapshot: &test_snapshot(&request, &result),
        parent_cmd_tx: Some(&cmd_tx),
        task_output_tool_name: "get_command_or_subagent_output",
        scheduler_delete_tool_name: Some("scheduler_delete"),
        scheduler_create_tool_name: Some("scheduler_create"),
        synthetic_trace_tx: &None,
    });
    let SessionCommand::SubagentCompletionWake { text: prompt, .. } = cmd_rx
        .try_recv()
        .expect("expected synthetic completion wake") else {
        panic!("expected SessionCommand::SubagentCompletionWake");
    };
    assert!(!prompt.contains("scheduler_delete"));
    assert!(!prompt.contains("no longer relevant"));
    assert!(!prompt.contains("Check the subagent output"));
}
#[test]
fn inject_subagent_completed_prompt_bails_when_parent_closed() {
    let (cmd_tx, cmd_rx) = mpsc::unbounded_channel::<SessionCommand>();
    drop(cmd_rx);
    let (trace_tx, mut trace_rx) = mpsc::unbounded_channel();
    let request = auto_wake_test_request("sa-closed");
    let result = SubagentResult {
        state: SubagentState::Completed,
        subagent_id: "sa-closed".into(),
        child_session_id: "sa-closed".into(),
        ..Default::default()
    };
    inject_subagent_completed_prompt(InjectParams {
        attempt_id: &xai_message_delivery_core::AttemptId::mint(1),
        subagent_id: "sa-closed",
        result: &result,
        request: &request,
        snapshot: &test_snapshot(&request, &result),
        parent_cmd_tx: Some(&cmd_tx),
        task_output_tool_name: "get_command_or_subagent_output",
        scheduler_delete_tool_name: None,
        scheduler_create_tool_name: None,
        synthetic_trace_tx: &Some(trace_tx),
    });
    assert!(trace_rx.try_recv().is_err(), "no prompt was sent, so no trace request follows");
}
#[test]
fn persist_gate_only_persists_successful_nonempty_outputs() {
    let dir = tempfile::tempdir().expect("tempdir");
    let ok = SubagentResult {
        state: SubagentState::Completed,
        output: std::sync::Arc::from("text"),
        ..Default::default()
    };
    assert_eq!(
            persist_subagent_output(dir.path(), &ok),
            Some(dir.path().to_path_buf())
        );
    let empty = SubagentResult {
        state: SubagentState::Completed,
        ..Default::default()
    };
    assert_eq!(persist_subagent_output(dir.path(), &empty), None);
    let failed = SubagentResult {
        state: SubagentState::Failed { message: "Unknown error".to_owned() },
        output: std::sync::Arc::from("partial"),
        ..Default::default()
    };
    assert_eq!(persist_subagent_output(dir.path(), &failed), None);
}
#[test]
fn subagent_output_roundtrips_through_output_json() {
    let dir = tempfile::tempdir().expect("tempdir");
    let output = "line one\nline two with unicode ✓";
    assert!(write_subagent_output(dir.path(), output));
    assert_eq!(read_subagent_output(dir.path()).as_deref(), Some(output));
    assert_eq!(read_subagent_output(&dir.path().join("missing")), None);
    std::fs::write(dir.path().join("output.json"), "not json").expect("corrupt file");
    assert_eq!(read_subagent_output(dir.path()), None);
}
#[test]
fn partial_override_fills_from_role() {
    let overrides = SubagentRuntimeOverrides {
        model: Some("explicit-model".into()),
        ..Default::default()
    };
    let role = xai_grok_subagent_resolution::config::SubagentRole {
        description: "test".into(),
        default_capability_mode: Some("execute".into()),
        ..Default::default()
    };
    let resolved = resolve_effective_overrides(
        &overrides,
        Some(&role),
        &HashMap::new(),
        None,
        None,
    );
    assert_eq!(resolved.model.as_deref(), Some("explicit-model"));
    assert_eq!(
            resolved.capability_mode,
            Some(xai_tool_types::SubagentCapabilityMode::Execute)
        );
}
#[test]
fn invalid_role_capability_mode_ignored() {
    let overrides = SubagentRuntimeOverrides::default();
    let role = xai_grok_subagent_resolution::config::SubagentRole {
        description: "test".into(),
        default_capability_mode: Some("invalid-mode".into()),
        ..Default::default()
    };
    let resolved = resolve_effective_overrides(
        &overrides,
        Some(&role),
        &HashMap::new(),
        None,
        None,
    );
    assert!(
            resolved.capability_mode.is_none(),
            "invalid role mode should not produce a capability_mode"
        );
}
#[test]
fn persona_resolved_from_config() {
    let overrides = SubagentRuntimeOverrides {
        persona: Some("researcher".into()),
        ..Default::default()
    };
    let mut personas = HashMap::new();
    personas
        .insert(
            "researcher".to_string(),
            xai_grok_subagent_resolution::config::SubagentPersona {
                instructions: Some("Be thorough.".into()),
                ..Default::default()
            },
        );
    let resolved = resolve_effective_overrides(&overrides, None, &personas, None, None);
    assert_eq!(resolved.persona.as_deref(), Some("researcher"));
    assert_eq!(
            resolved.persona_instructions.as_deref(),
            Some("Be thorough.")
        );
}
#[test]
fn persona_inline_plus_file_merged_in_order() {
    let tmp = tempfile::TempDir::new().unwrap();
    std::fs::write(tmp.path().join("extra.md"), "File-based content.").unwrap();
    let overrides = SubagentRuntimeOverrides {
        persona: Some("combo".into()),
        ..Default::default()
    };
    let mut personas = HashMap::new();
    personas
        .insert(
            "combo".to_string(),
            xai_grok_subagent_resolution::config::SubagentPersona {
                instructions: Some("Inline first.".into()),
                instructions_file: Some("extra.md".into()),
                ..Default::default()
            },
        );
    let resolved = resolve_effective_overrides(
        &overrides,
        None,
        &personas,
        Some(tmp.path()),
        None,
    );
    let pi = resolved.persona_instructions.as_deref().unwrap();
    assert!(
            pi.starts_with("Inline first."),
            "inline should come first: {pi}"
        );
    assert!(
            pi.contains("File-based content."),
            "file content should be included: {pi}"
        );
}
#[test]
fn model_precedence_explicit_over_role_over_persona() {
    let mut personas = HashMap::new();
    personas
        .insert(
            "dev".to_string(),
            xai_grok_subagent_resolution::config::SubagentPersona {
                model: Some("persona-model".into()),
                ..Default::default()
            },
        );
    let role = xai_grok_subagent_resolution::config::SubagentRole {
        description: "test".into(),
        model: Some("role-model".into()),
        ..Default::default()
    };
    let overrides = SubagentRuntimeOverrides {
        persona: Some("dev".into()),
        model: Some("explicit-model".into()),
        ..Default::default()
    };
    let r = resolve_effective_overrides(&overrides, Some(&role), &personas, None, None);
    assert_eq!(r.model.as_deref(), Some("explicit-model"));
    let overrides = SubagentRuntimeOverrides {
        persona: Some("dev".into()),
        ..Default::default()
    };
    let r = resolve_effective_overrides(&overrides, Some(&role), &personas, None, None);
    assert_eq!(r.model.as_deref(), Some("role-model"));
    let role_no_model = xai_grok_subagent_resolution::config::SubagentRole {
        description: "test".into(),
        ..Default::default()
    };
    let r = resolve_effective_overrides(
        &overrides,
        Some(&role_no_model),
        &personas,
        None,
        None,
    );
    assert_eq!(r.model.as_deref(), Some("persona-model"));
    let overrides = SubagentRuntimeOverrides::default();
    let r = resolve_effective_overrides(&overrides, None, &HashMap::new(), None, None);
    assert!(r.model.is_none());
}
#[test]
fn reasoning_effort_precedence_explicit_over_role_over_persona() {
    let mut personas = HashMap::new();
    personas
        .insert(
            "dev".to_string(),
            xai_grok_subagent_resolution::config::SubagentPersona {
                reasoning_effort: Some("low".into()),
                ..Default::default()
            },
        );
    let role = xai_grok_subagent_resolution::config::SubagentRole {
        description: "test".into(),
        reasoning_effort: Some("medium".into()),
        ..Default::default()
    };
    let overrides = SubagentRuntimeOverrides {
        persona: Some("dev".into()),
        reasoning_effort: Some("high".into()),
        ..Default::default()
    };
    let r = resolve_effective_overrides(&overrides, Some(&role), &personas, None, None);
    assert_eq!(r.reasoning_effort.as_deref(), Some("high"));
    let overrides = SubagentRuntimeOverrides {
        persona: Some("dev".into()),
        ..Default::default()
    };
    let r = resolve_effective_overrides(&overrides, Some(&role), &personas, None, None);
    assert_eq!(r.reasoning_effort.as_deref(), Some("medium"));
    let role_no_re = xai_grok_subagent_resolution::config::SubagentRole {
        description: "test".into(),
        ..Default::default()
    };
    let r = resolve_effective_overrides(
        &overrides,
        Some(&role_no_re),
        &personas,
        None,
        None,
    );
    assert_eq!(r.reasoning_effort.as_deref(), Some("low"));
    let overrides = SubagentRuntimeOverrides::default();
    let r = resolve_effective_overrides(&overrides, None, &HashMap::new(), None, None);
    assert!(r.reasoning_effort.is_none());
}
#[test]
fn persona_not_found_produces_error() {
    let overrides = SubagentRuntimeOverrides {
        persona: Some("missing".into()),
        ..Default::default()
    };
    let resolved = resolve_effective_overrides(
        &overrides,
        None,
        &HashMap::new(),
        None,
        None,
    );
    assert!(resolved.persona_error.is_some());
    assert!(
            resolved
                .persona_error
                .as_deref()
                .unwrap()
                .contains("not found"),
        );
}
#[test]
fn prompt_assembly_ordering() {
    let role_prompt = Some(
        "<role-instructions>\nRole content\n</role-instructions>".to_string(),
    );
    let persona_instructions = Some(
        "<persona>\nPersona content\n</persona>".to_string(),
    );
    let task = "Do the task";
    let mut sections = Vec::new();
    sections.push("<fork-context>...</fork-context>".to_string());
    if let Some(ref rp) = role_prompt {
        sections.push(rp.clone());
    }
    if let Some(ref pi) = persona_instructions {
        sections.push(pi.clone());
    }
    sections.push(task.to_string());
    let assembled = sections.join("\n\n");
    let fork_pos = assembled.find("<fork-context>").unwrap();
    let role_pos = assembled.find("<role-instructions>").unwrap();
    let persona_pos = assembled.find("<persona>").unwrap();
    let task_pos = assembled.find("Do the task").unwrap();
    assert!(fork_pos < role_pos, "fork before role");
    assert!(role_pos < persona_pos, "role before persona");
    assert!(persona_pos < task_pos, "persona before task");
}
#[test]
fn no_persona_produces_none() {
    let overrides = SubagentRuntimeOverrides::default();
    let resolved = resolve_effective_overrides(
        &overrides,
        None,
        &HashMap::new(),
        None,
        None,
    );
    assert!(resolved.persona.is_none());
    assert!(resolved.persona_instructions.is_none());
}
#[test]
fn forked_initial_context_normalizes_parent_history() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let items = vec![
            ConversationItem::system("parent system"),
            ConversationItem::user("UNIQUE_FORK_MARKER_abc123 implement multi-repo fix"),
            ConversationItem::assistant("noted"),
        ];
    let ctx = forked_initial_context(items);
    assert_eq!(ctx.context, SubagentContext::Forked(ForkMode::Summarized));
    assert_eq!(ctx.prefix_len, Some(2));
    assert_eq!(ctx.conversation.len(), 2);
    if let Some(ConversationItem::User(u)) = ctx.conversation.get(1) {
        let text: String = u
            .content
            .iter()
            .filter_map(|p| match p {
                xai_grok_sampling_types::conversation::ContentPart::Text { text } => {
                    Some(text.as_ref())
                }
                _ => None,
            })
            .collect();
        assert!(text.contains("<background_context>"));
        assert!(
                text.contains("UNIQUE_FORK_MARKER_abc123"),
                "distinctive parent token must appear in background: {text}"
            );
    } else {
        panic!("expected User background at [1]");
    }
}
#[test]
fn forked_initial_context_inherits_parent_across_reasoning() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let items = vec![
            ConversationItem::system("parent system"),
            ConversationItem::user("remember UNIQUE_FORK_MARKER_TEST"),
            ConversationItem::Reasoning(xai_grok_sampling_types::synthesized_reasoning_item(
                "deliberating",
            )),
            ConversationItem::assistant("ack"),
        ];
    let ctx = forked_initial_context(items);
    assert_eq!(ctx.context, SubagentContext::Forked(ForkMode::Summarized));
    assert_eq!(ctx.prefix_len, Some(2));
    assert_eq!(ctx.conversation.len(), 2);
    if let Some(ConversationItem::User(u)) = ctx.conversation.get(1) {
        let text: String = u
            .content
            .iter()
            .filter_map(|p| match p {
                xai_grok_sampling_types::conversation::ContentPart::Text { text } => {
                    Some(text.as_ref())
                }
                _ => None,
            })
            .collect();
        assert!(
                text.contains("<background_context>"),
                "background wrapper must be present: {text}"
            );
        assert!(
                text.contains("UNIQUE_FORK_MARKER_TEST"),
                "parent context must be inherited across the reasoning sibling: {text}"
            );
    } else {
        panic!("expected User background at [1]");
    }
}
#[test]
fn forked_initial_context_empty_fails_open_to_new() {
    let ctx = forked_initial_context(vec![]);
    assert_eq!(ctx.context, SubagentContext::ForkFailed(ForkFailure::EmptyParent));
    assert!(ctx.conversation.is_empty());
}
#[test]
fn resume_vs_fork_helper_shapes_differ() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let resume_items = vec![
            ConversationItem::system("child system"),
            ConversationItem::user("prior subagent work"),
            ConversationItem::assistant("done"),
        ];
    let resumed = resume_initial_context(resume_items.clone(), false);
    let forked = forked_initial_context(resume_items);
    assert_eq!(resumed.context, SubagentContext::Resumed);
    assert_eq!(forked.context, SubagentContext::Forked(ForkMode::Summarized));
    assert!(resumed.conversation.len() > forked.conversation.len());
    assert!(!matches!(
            resumed.conversation.get(1),
            Some(ConversationItem::User(u))
                if u.content.iter().any(|p| matches!(
                    p,
                    xai_grok_sampling_types::conversation::ContentPart::Text { text }
                        if text.contains("<background_context>")
                ))
        ));
}
#[test]
fn forked_initial_context_applies_fork_filter_before_normalize() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let items = vec![
            ConversationItem::system("sys"),
            ConversationItem::user("complete user"),
            ConversationItem::assistant("complete asst"),
            ConversationItem::user("INCOMPLETE_TRAILING"),
        ];
    let ctx = forked_initial_context(items);
    assert_eq!(ctx.context, SubagentContext::Forked(ForkMode::Summarized));
    if let Some(ConversationItem::User(u)) = ctx.conversation.get(1) {
        let text: String = u
            .content
            .iter()
            .filter_map(|p| match p {
                xai_grok_sampling_types::conversation::ContentPart::Text { text } => {
                    Some(text.as_ref())
                }
                _ => None,
            })
            .collect();
        assert!(text.contains("complete user"));
        assert!(
                !text.contains("INCOMPLETE_TRAILING"),
                "fork_filter must truncate incomplete trailing turn: {text}"
            );
    } else {
        panic!("expected background user");
    }
}
#[test]
fn verbatim_fork_keeps_items_byte_for_byte_when_small() {
    use xai_grok_sampling_types::conversation::{
        ContentPart, ConversationItem, SyntheticReason, UserItem,
    };
    let items = vec![
            ConversationItem::system("parent system"),
            ConversationItem::user("remember UNIQUE_FORK_MARKER_TEST"),
            ConversationItem::User(UserItem {
                content: vec![ContentPart::Text {
                    text: "SYNTHETIC_KEEP_ME".into(),
                }],
                synthetic_reason: SyntheticReason::SystemReminder,
                ..Default::default()
            }),
            ConversationItem::Reasoning(xai_grok_sampling_types::synthesized_reasoning_item(
                "thinking",
            )),
            ConversationItem::assistant("ack"),
        ];
    let ctx = verbatim_or_normalize_fork(items, 256_000);
    assert!(
            ctx.is_verbatim_fork(),
            "a small, complete-tail parent must mirror verbatim"
        );
    assert_eq!(ctx.prefix_len, Some(5));
    assert_eq!(ctx.conversation.len(), 5);
    assert!(matches!(
            ctx.conversation.first(),
            Some(ConversationItem::System(_))
        ));
    assert!(matches!(
            ctx.conversation.last(),
            Some(ConversationItem::Assistant(_))
        ));
    let text_present = |needle: &str| {
        ctx
            .conversation
            .iter()
            .any(|i| {
                matches!(i, ConversationItem::User(u)
                    if u.content.iter().any(|p| matches!(p,
                        ContentPart::Text { text } if text.contains(needle))))
            })
    };
    assert!(
            text_present("UNIQUE_FORK_MARKER_TEST"),
            "marker must survive verbatim"
        );
    assert!(
            text_present("SYNTHETIC_KEEP_ME"),
            "synthetic-reason item must be preserved verbatim, NOT stripped"
        );
    assert!(
            ctx.conversation
                .iter()
                .any(|i| matches!(i, ConversationItem::User(u) if !u.synthetic_reason.is_human())),
            "the synthetic_reason marker itself must remain in the verbatim mirror"
        );
    assert!(
            !text_present("<background_context>"),
            "verbatim fork must NOT summarize into a background blob"
        );
}
#[test]
fn verbatim_fork_falls_back_to_summary_on_incomplete_tail() {
    use xai_grok_sampling_types::conversation::{
        AssistantItem, ContentPart, ConversationItem, ToolCall,
    };
    let items = vec![
            ConversationItem::system("parent system"),
            ConversationItem::user("q1 UNIQUE_FORK_MARKER_TEST"),
            ConversationItem::assistant("a1"),
            ConversationItem::user("q2"),
            ConversationItem::Assistant(AssistantItem {
                content: String::new().into(),
                tool_calls: vec![ToolCall {
                    id: "tc1".into(),
                    name: "bash".into(),
                    arguments: "{}".into(),
                }],
                model_id: None,
                model_fingerprint: None,
                reasoning_effort: None,
            }),
        ];
    let ctx = verbatim_or_normalize_fork(items, 256_000);
    assert_eq!(ctx.context, SubagentContext::Forked(ForkMode::Summarized));
    assert!(
            !ctx.is_verbatim_fork(),
            "an incomplete (dangling tool call) tail must fall back to summary"
        );
    assert_eq!(ctx.prefix_len, Some(2));
    assert!(
            ctx.conversation.iter().any(|i| {
                matches!(i, ConversationItem::User(u)
                    if u.content.iter().any(|p| matches!(p,
                        ContentPart::Text { text } if text.contains("<background_context>"))))
            }),
            "summarized fallback must produce a background_context blob"
        );
}
#[test]
fn summarized_fork_is_not_a_verbatim_mirror() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let items = vec![
            ConversationItem::system("parent system prompt"),
            ConversationItem::user("turn one UNIQUE_FORK_MARKER_TEST"),
            ConversationItem::assistant("ack"),
        ];
    let ctx = verbatim_or_normalize_fork(items, 1);
    assert_eq!(ctx.context, SubagentContext::Forked(ForkMode::Summarized));
    let verbatim_mirror_fork = ctx.is_verbatim_fork();
    assert!(
            !verbatim_mirror_fork,
            "a summarized fork must NOT be treated as a verbatim mirror"
        );
}
#[test]
fn verbatim_fork_falls_back_to_summary_when_oversize() {
    use xai_grok_sampling_types::conversation::{ContentPart, ConversationItem};
    let items = vec![
            ConversationItem::system("parent system"),
            ConversationItem::user("turn one UNIQUE_FORK_MARKER_TEST with some text"),
            ConversationItem::assistant("ack one"),
        ];
    let ctx = verbatim_or_normalize_fork(items, 1);
    assert_eq!(ctx.context, SubagentContext::Forked(ForkMode::Summarized));
    assert!(
            !ctx.is_verbatim_fork(),
            "oversize parent must fall back to summary"
        );
    assert_eq!(ctx.prefix_len, Some(2));
    let has_blob = ctx
        .conversation
        .iter()
        .any(|i| {
            matches!(i, ConversationItem::User(u)
                if u.content.iter().any(|p| matches!(p,
                    ContentPart::Text { text } if text.contains("<background_context>"))))
        });
    assert!(
            has_blob,
            "oversize fallback must produce a background_context blob"
        );
}
#[test]
fn verbatim_fork_empty_after_filter_fails_open_to_new() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let items = vec![ConversationItem::user("/goal do the thing")];
    let ctx = verbatim_or_normalize_fork(items, 256_000);
    assert_eq!(
        ctx.context,
        SubagentContext::ForkFailed(ForkFailure::NoInheritableContent)
    );
    assert!(ctx.conversation.is_empty());
}
#[test]
fn forked_initial_context_system_only_fails_open_to_new() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let ctx = forked_initial_context(vec![ConversationItem::system("sys")]);
    assert_eq!(
        ctx.context,
        SubagentContext::ForkFailed(ForkFailure::NoInheritableContent)
    );
    assert!(ctx.conversation.is_empty());
}
#[test]
fn fork_context_normalized_only_for_summarized() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let verbatim = verbatim_or_normalize_fork(
        vec![
                ConversationItem::system("sys"),
                ConversationItem::user("q"),
                ConversationItem::assistant("a"),
            ],
        256_000,
    );
    assert_eq!(verbatim.context, SubagentContext::Forked(ForkMode::Verbatim));
    assert!(!verbatim.context.is_summarized_fork());
    let summarized = verbatim_or_normalize_fork(
        vec![
                ConversationItem::system("sys"),
                ConversationItem::user("q with text"),
                ConversationItem::assistant("a"),
            ],
        1,
    );
    assert!(summarized.context.is_summarized_fork());
}
fn background_text(ctx: &InitialContext) -> String {
    use xai_grok_sampling_types::conversation::{ContentPart, ConversationItem};
    ctx.conversation
        .iter()
        .filter_map(|item| match item {
            ConversationItem::User(u) => Some(u.content.iter()),
            _ => None,
        })
        .flatten()
        .filter_map(|part| match part {
            ContentPart::Text { text } => Some(text.as_ref()),
            _ => None,
        })
        .collect()
}
#[test]
fn planner_fork_with_dangling_tool_call_stays_forked() {
    use xai_grok_sampling_types::conversation::{AssistantItem, ConversationItem, ToolCall};
    let items = vec![
        ConversationItem::system("parent system"),
        ConversationItem::user("UNIQUE_RUNNING_TURN_MARKER migrate the clean planner"),
        ConversationItem::Assistant(AssistantItem {
            content: "checking the build".into(),
            tool_calls: vec![ToolCall {
                id: "tc-running".into(),
                name: "run_terminal_command".into(),
                arguments: "{}".into(),
            }],
            model_id: None,
            model_fingerprint: None,
            reasoning_effort: None,
        }),
    ];
    let ctx = verbatim_or_normalize_fork(items, 256_000);
    assert!(
        ctx.context.is_summarized_fork(),
        "an unfinished tool call must not cost the whole fork: {:?}",
        ctx.context
    );
    assert!(background_text(&ctx).contains("UNIQUE_RUNNING_TURN_MARKER"));
}
#[test]
fn planner_fork_right_after_compaction_stays_forked() {
    use xai_grok_sampling_types::conversation::{
        ContentPart, ConversationItem, SyntheticReason, UserItem,
    };
    let synthetic = |text: &str, reason: SyntheticReason| {
        ConversationItem::User(UserItem {
            content: vec![ContentPart::Text { text: text.into() }],
            synthetic_reason: reason,
            ..Default::default()
        })
    };
    let items = vec![
        ConversationItem::system("parent system"),
        synthetic("<user_info>os</user_info>", SyntheticReason::CompactionMeta),
        ConversationItem::user("latest build result"),
        synthetic(
            "This session is being continued. UNIQUE_COMPACTION_SUMMARY_MARKER",
            SyntheticReason::CompactionMeta,
        ),
        synthetic("<system-reminder>skills</system-reminder>", SyntheticReason::SystemReminder),
    ];
    let ctx = verbatim_or_normalize_fork(items, 256_000);
    assert!(
        ctx.context.is_summarized_fork(),
        "a freshly compacted parent must still fork its summary: {:?}",
        ctx.context
    );
    let text = background_text(&ctx);
    assert!(text.contains("UNIQUE_COMPACTION_SUMMARY_MARKER"), "{text}");
    assert!(!text.contains("skills"), "runtime reminders stay out: {text}");
}
fn bootstrap_test_request(fork_context: bool) -> SubagentRequest {
    SubagentRequest {
        id: "bootstrap-test".into(),
        prompt: "plan".into(),
        description: "d".into(),
        subagent_type: "general-purpose".into(),
        parent_session_id: "parent".into(),
        parent_prompt_id: None,
        resume_from: None,
        cwd: None,
        runtime_overrides: Default::default(),
        run_in_background: false,
        surface_completion: false,
        await_to_completion: false,
        fork_context,
        owner: SubagentOwner::Task,
        cancel_token: CancellationToken::new(),
        spawn_root: Default::default(),
        tool_call_id: None,
    }
}
#[tokio::test]
async fn bootstrap_in_place_resume_reads_existing_transcript() {
    use crate::session::storage::StorageAdapter;
    use crate::session::storage::jsonl::JsonlStorageAdapter;
    use xai_grok_sampling_types::conversation::ConversationItem;
    let temp = tempfile::TempDir::new().unwrap();
    let child = SessionInfo {
        id: acp::SessionId::new("same-child"),
        cwd: temp.path().to_string_lossy().into_owned(),
    };
    let child_dir = temp.path().join("child-session");
    let storage = JsonlStorageAdapter::with_explicit_session_dir(child_dir.clone());
    storage.init_session(&child, acp::ModelId::new("test-model")).await.unwrap();
    storage
        .append_chat_message(&child, &ConversationItem::system("system"))
        .await
        .unwrap();
    storage
        .append_chat_message(&child, &ConversationItem::user("previous work"))
        .await
        .unwrap();
    let request = bootstrap_test_request(false);
    let source = xai_grok_subagent_resolution::ResumeSourceData {
        subagent_id: "same-child".to_owned(),
        child_session_id: "same-child".to_owned(),
        child_cwd: child.cwd.clone(),
        worktree_path: None,
        snapshot_ref: None,
        subagent_type: "general-purpose".to_owned(),
        persona: None,
        model_id: Some("test-model".to_owned()),
    };
    let out = bootstrap_initial_context(
            &request,
            Some(&source),
            &ctx_with_toggle(HashMap::new()),
            &child,
            &child_dir,
            "test-model",
            super::resume_window::ResumeWindowPolicy {
                context_window: 128_000,
                auto_compact_threshold_percent: 85,
            },
        )
        .await;
    match out {
        BootstrapInitialContext::Ready(initial) => {
            assert_eq!(initial.context, SubagentContext::Resumed);
            assert_eq!(initial.conversation.len(), 2);
        }
        BootstrapInitialContext::ResumeAbort(message) => {
            panic!("unexpected abort: {message}")
        }
    }
}
#[tokio::test]
async fn bootstrap_no_fork_is_new() {
    let req = bootstrap_test_request(false);
    let ctx = ctx_with_toggle(HashMap::new());
    let child = SessionInfo {
        id: acp::SessionId::new("child-boot"),
        cwd: "/tmp".into(),
    };
    let out = bootstrap_initial_context(
            &req,
            None,
            &ctx,
            &child,
            Path::new("/tmp"),
            "m",
            super::resume_window::ResumeWindowPolicy {
                context_window: 128_000,
                auto_compact_threshold_percent: 85,
            },
        )
        .await;
    match out {
        BootstrapInitialContext::Ready(ic) => {
            assert_eq!(ic.context, SubagentContext::Fresh);
            assert!(ic.conversation.is_empty());
        }
        BootstrapInitialContext::ResumeAbort(m) => panic!("unexpected abort: {m}"),
    }
}
#[tokio::test]
async fn bootstrap_fork_without_parent_fails_open() {
    let req = bootstrap_test_request(true);
    let mut ctx = ctx_with_toggle(HashMap::new());
    ctx.parent_chat_state = None;
    ctx.parent_session_info = None;
    let child = SessionInfo {
        id: acp::SessionId::new("child-boot2"),
        cwd: "/tmp".into(),
    };
    let out = bootstrap_initial_context(
            &req,
            None,
            &ctx,
            &child,
            Path::new("/tmp"),
            "m",
            super::resume_window::ResumeWindowPolicy {
                context_window: 128_000,
                auto_compact_threshold_percent: 85,
            },
        )
        .await;
    match out {
        BootstrapInitialContext::Ready(ic) => {
            assert_eq!(
                ic.context,
                SubagentContext::ForkFailed(ForkFailure::ParentUnavailable)
            );
        }
        BootstrapInitialContext::ResumeAbort(m) => {
            panic!("fork must fail open, not abort: {m}")
        }
    }
}
#[tokio::test]
async fn bootstrap_fork_live_parent_chat_state_is_forked_with_marker() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    const MARKER: &str = "UNIQUE_LIVE_FORK_MARKER_xyz789";
    let req = bootstrap_test_request(true);
    let mut ctx = ctx_with_toggle(HashMap::new());
    let chat = spawn_test_parent_chat_state("grok-4.5");
    chat.replace_conversation(
        vec![
            ConversationItem::system("parent system"),
            ConversationItem::user(format!("{MARKER} implement multi-repo fix")),
            ConversationItem::assistant("noted the multi-repo work"),
        ],
    );
    ctx.parent_chat_state = Some(chat);
    ctx.parent_session_info = None;
    let child = SessionInfo {
        id: acp::SessionId::new("child-boot-live"),
        cwd: "/tmp".into(),
    };
    let out = bootstrap_initial_context(
            &req,
            None,
            &ctx,
            &child,
            Path::new("/tmp"),
            "m",
            super::resume_window::ResumeWindowPolicy {
                context_window: 128_000,
                auto_compact_threshold_percent: 85,
            },
        )
        .await;
    match out {
        BootstrapInitialContext::Ready(ic) => {
            assert!(
                    ic.is_verbatim_fork(),
                    "small complete-tail parent must mirror verbatim"
                );
            assert_eq!(ic.conversation.len(), 3);
            assert_eq!(ic.prefix_len, Some(3));
            assert!(matches!(
                    ic.conversation.first(),
                    Some(ConversationItem::System(_))
                ));
            assert!(matches!(
                    ic.conversation.get(1),
                    Some(ConversationItem::User(_))
                ));
            assert!(matches!(
                    ic.conversation.get(2),
                    Some(ConversationItem::Assistant(_))
                ));
            let text: String = ic
                .conversation
                .iter()
                .filter_map(|item| match item {
                    ConversationItem::User(u) => {
                        Some(
                            u
                                .content
                                .iter()
                                .filter_map(|p| match p {
                                    xai_grok_sampling_types::conversation::ContentPart::Text {
                                        text,
                                    } => Some(text.as_ref()),
                                    _ => None,
                                })
                                .collect::<String>(),
                        )
                    }
                    _ => None,
                })
                .collect();
            assert!(
                    text.contains(MARKER),
                    "live parent marker must appear verbatim: {text}"
                );
            assert!(
                    !text.contains("<background_context>"),
                    "verbatim mirror must NOT wrap items in a background_context blob: {text}"
                );
        }
        BootstrapInitialContext::ResumeAbort(m) => panic!("unexpected abort: {m}"),
    }
}
#[tokio::test]
async fn copy_session_data_preserves_parent_chat_history() {
    use crate::sampling::ConversationItem;
    use crate::session::storage::StorageAdapter;
    use crate::session::storage::jsonl::JsonlStorageAdapter;
    let tmp = tempfile::TempDir::new().unwrap();
    let root = tmp.path();
    let adapter = JsonlStorageAdapter::with_root(root.to_path_buf());
    let parent_info = SessionInfo {
        id: acp::SessionId::new("parent-fork-test"),
        cwd: "/workspace".to_string(),
    };
    adapter.init_session(&parent_info, acp::ModelId::new("test-model")).await.unwrap();
    adapter
        .append_chat_message(&parent_info, &ConversationItem::user("What files?"))
        .await
        .unwrap();
    adapter
        .append_chat_message(&parent_info, &ConversationItem::assistant("listed"))
        .await
        .unwrap();
    let child_info = SessionInfo {
        id: acp::SessionId::new("child-fork-test"),
        cwd: "/workspace".to_string(),
    };
    let result = adapter
        .copy_session_data_sync(
            &parent_info,
            &child_info,
            crate::session::storage::CopySessionOptions {
                parent_session_id: Some("parent-fork-test".to_string()),
                new_model_id: Some("test-model".to_string()),
                session_kind: Some("subagent_fork".to_string()),
                fork_context_source: Some("forked".to_string()),
                copy_plan_state: false,
                copy_plan_mode_state: false,
                copy_signals: false,
                copy_usage: false,
                copy_tool_state: false,
                fork_filter: true,
                ..Default::default()
            },
        )
        .unwrap();
    assert!(result.chat_messages_copied > 0, "should copy chat history");
    let child_data = adapter.load_session(&child_info).await.unwrap();
    assert_eq!(
            child_data.summary.session_kind.as_deref(),
            Some("subagent_fork")
        );
    assert_eq!(
            child_data.summary.fork_context_source.as_deref(),
            Some("forked")
        );
    assert_eq!(
            child_data.summary.parent_session_id.as_deref(),
            Some("parent-fork-test")
        );
    assert!(
            !child_data.chat_history.is_empty(),
            "child should have inherited parent chat history"
        );
}
fn make_validation_ctx(toggle: HashMap<String, bool>) -> SubagentValidationContext {
    SubagentValidationContext {
        parent_cwd: PathBuf::from("/tmp"),
        subagent_toggle: toggle,
        ..Default::default()
    }
}
#[test]
fn validate_subagent_type_returns_ok_for_known_enabled_agent() {
    let ctx = make_validation_ctx(HashMap::new());
    let outcome = validate_subagent_type("explore", &ctx);
    assert!(
            matches!(outcome, SubagentValidateTypeOutcome::Ok),
            "expected Ok, got {outcome:?}",
        );
}
#[test]
fn validate_subagent_type_returns_unknown_for_invented_type() {
    let ctx = make_validation_ctx(HashMap::new());
    let outcome = validate_subagent_type("totally-invented-agent-name", &ctx);
    match outcome {
        SubagentValidateTypeOutcome::Unknown { available } => {
            for expected in ["general-purpose", "explore", "plan"] {
                assert!(
                        available.iter().any(|n| n == expected),
                        "available list must include built-in {expected:?}: {available:?}",
                    );
            }
            let mut sorted = available.clone();
            sorted.sort();
            assert_eq!(available, sorted, "available must be sorted");
        }
        other => panic!("expected Unknown, got {other:?}"),
    }
}
#[test]
fn validate_subagent_type_returns_disabled_when_toggled_off() {
    let toggle = HashMap::from([("explore".to_string(), false)]);
    let ctx = make_validation_ctx(toggle);
    let outcome = validate_subagent_type("explore", &ctx);
    assert!(
            matches!(outcome, SubagentValidateTypeOutcome::Disabled),
            "expected Disabled, got {outcome:?}",
        );
}
#[test]
fn validate_subagent_type_returns_not_allowed_when_outside_allow_list() {
    let mut ctx = make_validation_ctx(HashMap::new());
    ctx.allowed_subagent_types = Some(vec!["plan".to_string()]);
    let outcome = validate_subagent_type("explore", &ctx);
    match outcome {
        SubagentValidateTypeOutcome::NotAllowed { allowed } => {
            assert_eq!(allowed, vec!["plan".to_string()]);
        }
        other => panic!("expected NotAllowed, got {other:?}"),
    }
}
#[test]
fn validate_subagent_type_allow_list_is_case_insensitive() {
    for (requested, allowed) in [
        ("explore", vec!["EXPLORE".to_string()]),
        ("EXPLORE", vec!["explore".to_string()]),
        ("Explore", vec!["eXpLoRe".to_string()]),
        ("explore", vec!["plan".to_string(), "EXPLORE".to_string()]),
    ] {
        let mut ctx = make_validation_ctx(HashMap::new());
        ctx.cli_agent_names = vec![requested.to_string()];
        ctx.allowed_subagent_types = Some(allowed.clone());
        assert!(
                matches!(
                    validate_subagent_type(requested, &ctx),
                    SubagentValidateTypeOutcome::Ok,
                ),
                "{requested:?} should be permitted by allow-list {allowed:?}",
            );
    }
}
#[test]
fn validate_subagent_type_unknown_includes_cli_agents_in_available() {
    let mut ctx = make_validation_ctx(HashMap::new());
    ctx.cli_agent_names = vec!["user-defined-agent".to_string()];
    match validate_subagent_type("invented", &ctx) {
        SubagentValidateTypeOutcome::Unknown { available } => {
            assert!(
                    available.iter().any(|n| n == "user-defined-agent"),
                    "cli agent name missing from available list: {available:?}",
                );
        }
        other => panic!("expected Unknown, got {other:?}"),
    }
}
#[test]
fn validate_subagent_type_unknown_dedupes_cli_against_builtins() {
    let mut ctx = make_validation_ctx(HashMap::new());
    ctx.cli_agent_names = vec!["explore".to_string()];
    match validate_subagent_type("invented", &ctx) {
        SubagentValidateTypeOutcome::Unknown { available } => {
            let count = available.iter().filter(|n| n.as_str() == "explore").count();
            assert_eq!(count, 1, "explore must appear once: {available:?}");
        }
        other => panic!("expected Unknown, got {other:?}"),
    }
}
#[test]
fn validate_subagent_type_unknown_omits_disabled_types_from_available_list() {
    let toggle = HashMap::from([("explore".to_string(), false)]);
    let ctx = make_validation_ctx(toggle);
    match validate_subagent_type("explor", &ctx) {
        SubagentValidateTypeOutcome::Unknown { available } => {
            assert!(
                    !available.iter().any(|n| n == "explore"),
                    "disabled type must not appear in available: {available:?}",
                );
            assert!(
                    available.iter().any(|n| n == "general-purpose"),
                    "non-disabled built-ins must still appear: {available:?}",
                );
        }
        other => panic!("expected Unknown, got {other:?}"),
    }
}
#[test]
fn validate_subagent_type_accepts_plugin_types_and_lists_them_when_unknown() {
    use xai_grok_agent::plugins::SharedPluginRegistryHandle;
    use xai_grok_agent::plugins::discovery::DiscoveryConfig;
    let workdir = tempfile::tempdir().expect("workdir");
    let plugin_dir = workdir.path().join("demo-plugin");
    std::fs::create_dir_all(plugin_dir.join("agents")).expect("plugin agents dir");
    std::fs::write(plugin_dir.join("plugin.json"), r#"{"name":"demo-plugin"}"#)
        .expect("plugin manifest");
    std::fs::write(
            plugin_dir.join("agents").join("reviewer.md"),
            "---\nname: reviewer\ndescription: Reviews diffs.\n---\n\nReview the diff.\n",
        )
        .expect("plugin agent");
    let registry = SharedPluginRegistryHandle::new(None, Vec::new())
        .build_for_cwd(
            workdir.path(),
            &DiscoveryConfig {
                cli_plugin_dirs: Vec::new(),
                config_paths: Vec::new(),
                disabled: Vec::new(),
                enabled: Vec::new(),
            },
            &[plugin_dir],
            false,
        );
    let ctx = SubagentValidationContext {
        parent_cwd: workdir.path().to_path_buf(),
        plugin_registry: registry,
        ..Default::default()
    };
    assert!(matches!(
            validate_subagent_type("demo-plugin:reviewer", &ctx),
            SubagentValidateTypeOutcome::Ok,
        ));
    match validate_subagent_type("demo-plugin:invented", &ctx) {
        SubagentValidateTypeOutcome::Unknown { available } => {
            assert!(
                    available.iter().any(|n| n == "demo-plugin:reviewer"),
                    "plugin type missing from available list: {available:?}",
                );
        }
        other => panic!("expected Unknown, got {other:?}"),
    }
}
#[test]
fn validate_subagent_type_recognizes_cli_agent_by_name() {
    let mut ctx = make_validation_ctx(HashMap::new());
    ctx.cli_agent_names = vec!["user-defined".to_string()];
    assert!(matches!(
            validate_subagent_type("user-defined", &ctx),
            SubagentValidateTypeOutcome::Ok,
        ));
}
#[test]
fn summarize_tool_config_uses_name_override_and_strips_namespace() {
    use xai_grok_tools::registry::types::{ToolConfig, ToolServerConfig};
    use xai_grok_tools::types::tool::ToolKind;
    let mut read = ToolConfig::from_id("GrokBuild:read_file");
    read.kind = Some(ToolKind::Read);
    let mut read_dup = ToolConfig::from_id("Codex:read_file");
    read_dup.kind = Some(ToolKind::Read);
    read_dup.name_override = Some("codex_read".to_string());
    let mut grep = ToolConfig::from_id("OpenCode:grep");
    grep.kind = Some(ToolKind::Search);
    grep.name_override = Some("alt_grep".to_string());
    let mcp = ToolConfig::from_id("MCP:custom");
    let config = ToolServerConfig {
        tools: vec![read, read_dup, grep, mcp],
        behavior_preset: None,
    };
    let summary = summarize_tool_config(&config);
    assert_eq!(
            summary.tool_names.get(&ToolKind::Read).unwrap(),
            "read_file"
        );
    assert_eq!(
            summary.tool_names.get(&ToolKind::Search).unwrap(),
            "alt_grep"
        );
    assert!(summary.can_read && summary.can_search && !summary.can_execute);
    assert_eq!(summary.tool_names.len(), 2);
}
#[test]
fn describe_subagent_type_unknown_returns_sorted_available() {
    let ctx = ctx_with_toggle(HashMap::new());
    match describe_subagent_type("totally-invented-type", None, &ctx) {
        SubagentDescribeOutcome::Unknown { available } => {
            let mut sorted = available.clone();
            sorted.sort();
            assert_eq!(available, sorted, "available must be sorted");
            assert!(available.iter().any(|n| n == "general-purpose"));
        }
        other => panic!("expected Unknown, got {other:?}"),
    }
}
/// Regression guard for the DEFAULT grok-build host, the primary `/goal` host. There the only `general-purpose` tool that edits files is `search_replace` (`ToolKind::Edit`).
/// The `write` tool (`ToolKind::Write`) is only injected later, so the pre-injection describe probe never lists it. The planner gate must therefore key on the Edit capability.
#[test]
fn describe_default_host_general_purpose_has_edit_not_write() {
    use xai_grok_tools::types::tool::ToolKind;
    let ctx = ctx_with_toggle(HashMap::new());
    let SubagentDescribeOutcome::Ok(summary) = describe_subagent_type(
        "general-purpose",
        None,
        &ctx,
    ) else {
        panic!("expected Ok for default-host general-purpose");
    };
    assert!(summary.can_read, "default host reads (read_file)");
    assert!(
            summary.tool_names.contains_key(&ToolKind::Edit),
            "default host's file-mutator is search_replace (Edit): {:?}",
            summary.tool_names,
        );
    assert!(
            !summary.tool_names.contains_key(&ToolKind::Write),
            "the injection-only `write` tool must NOT be in the pre-injection probe",
        );
}
/// An `agent_type` that does not resolve to a harness `AgentDefinition` reports `Unknown`.
/// The `/goal` resolver maps that to a `ToolsetUnknown` fail-open to the session harness.
#[test]
fn goal_harness_override_unresolvable_returns_unknown() {
    let ctx = ctx_with_toggle(HashMap::new());
    match describe_subagent_type(
        "general-purpose",
        Some("totally-bogus-harness"),
        &ctx,
    ) {
        SubagentDescribeOutcome::Unknown { .. } => {}
        other => {
            panic!("an unresolvable harness override must fail open as Unknown: {other:?}")
        }
    }
}
/// The model fallback only fires for a strict harness.
/// A custom profile running a stock/vision model leaves subagents on the default harness, so they keep native image input.
#[test]
fn subagent_keeps_default_flavor_when_parent_model_is_non_strict() {
    use xai_grok_agent::config::BuiltinAgentName;
    let mut ctx = ctx_with_toggle(HashMap::new());
    ctx.parent_agent_name = Some("ai-oncall-bot".to_string());
    ctx.parent_model_agent_type = Some(
        BuiltinAgentName::GrokBuildPlan.as_ref().to_string(),
    );
    let mut def = resolve_agent_definition("general-purpose", &ctx).expect("resolves");
    resolve_subagent_toolset("general-purpose", None, &ctx, &mut def);
    assert!(
            !crate::session::is_cursor_user_template(&def.user_message_template),
            "a non-strict parent model must leave subagents on the default harness",
        );
}
fn test_gcs_context(ctx: &SubagentSpawnContext) -> GcsUploadContext {
    GcsUploadContext {
        bucket_url: None,
        upload_method: None,
        model_id: None,
        cwd: None,
        isolation_mode: None,
        capability_mode: None,
        reasoning_effort: None,
        role_name: None,
        parent_prompt_id: None,
        depth: 0,
        auth_manager: ctx.auth_manager.clone(),
    }
}
#[tokio::test]
async fn cancel_pending_shell_child_presents_one_cancelled_finish() {
    let mut ctx = ctx_with_toggle(HashMap::new());
    let fixture = DurableCompletionFixture::new(&mut ctx).await;
    let (child_cmd_tx, mut child_cmd_rx) = mpsc::unbounded_channel();
    let (gateway, mut gateway_rx) = test_gateway_with_receiver();
    let mut request = auto_wake_test_request("promote-cancel");
    request.parent_session_id = ctx.parent_session_id.clone();
    let meta_dir = fixture.directory.path().join("subagents").join(&request.id);
    let completion_data = pending_shell_completion_fixture(&ctx, xai_chat_state::SubagentCompletionId {
        subagent_id: request.id.clone(),
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
    }, &meta_dir);
    let result = cancel_pending_shell_child(
            &child_cmd_tx,
            SessionThread::from_handle(std::thread::spawn(|| {})),
            &ctx.workspace_ops,
            &request.id,
            &acp::SessionId::new(request.id.clone()),
            &meta_dir,
            None,
            false,
            42,
            &test_gcs_context(&ctx),
            UNPROMOTED_SESSION_THREAD_EXIT_TIMEOUT,
            UnpromotedChildDisposition::Cancelled,
            true,
            &completion_data,
        )
        .await;
    assert!(matches!(child_cmd_rx.try_recv(), Ok(SessionCommand::Cancel(_))));
    assert!(matches!(
            child_cmd_rx.try_recv(),
            Ok(SessionCommand::Shutdown(_))
        ));
    assert!(result.is_interrupted());
    assert!(!result.success());
    completion_data.mark_spawned_notification_emitted();
    let completion = ChildCompletion {
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
        snapshot: test_snapshot(&request, &result),
        request,
        result,
        completion_data,
        disposition: CompletionDisposition {
            foreground_delivered: false,
            backgrounded: false,
            waiter_delivered: false,
            explicitly_killed: false,
            reporting: xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Silent,
        },
    };
    let will_wake = will_wake_for(&completion);
    assert!(!will_wake);
    prepare_completion_admission(&completion).await.expect("actual producer commit");
    assert!(matches!(
        publish_committed_completion(completion, gateway).await,
        xai_grok_tools::implementations::grok_build::task::coordinator::TerminalVisibilityResult::Published
    ));
    let updates = fixture.storage.load_session(&fixture.info).await.expect("actual persisted lifecycle").updates;
    let persisted = updates.iter().filter(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification) if matches!(&notification.update,
            SessionUpdate::SubagentFinished { subagent_id, status, .. } if subagent_id == "promote-cancel" && status == "cancelled"))).count();
    assert_eq!(persisted, 1);
    let mut live = 0;
    while let Ok(message) = gateway_rx.try_recv() {
        if matches!(
                message,
                xai_acp_lib::AcpClientMessage::ExtNotification(args)
                    if args.request.params.get().contains("\"status\":\"cancelled\"")
            ) {
            live += 1;
        }
    }
    assert_eq!(live, 1);
}
async fn run_promote_cancel_with_worktree(
    worktree: &Path,
    worktree_freshly_created: bool,
) {
    let ctx = ctx_with_toggle(HashMap::new());
    let (child_cmd_tx, mut child_cmd_rx) = mpsc::unbounded_channel();
    let meta_dir = tempfile::tempdir().expect("meta dir");
    let completion_data = pending_shell_completion_fixture(&ctx, xai_chat_state::SubagentCompletionId {
        subagent_id: "worktree-cancel".into(),
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
    }, meta_dir.path());
    let result = cancel_pending_shell_child(
            &child_cmd_tx,
            SessionThread::from_handle(std::thread::spawn(|| {})),
            &ctx.workspace_ops,
            "worktree-cancel",
            &acp::SessionId::new("worktree-cancel"),
            meta_dir.path(),
            Some(worktree),
            worktree_freshly_created,
            42,
            &test_gcs_context(&ctx),
            UNPROMOTED_SESSION_THREAD_EXIT_TIMEOUT,
            UnpromotedChildDisposition::Cancelled,
            true,
            &completion_data,
        )
        .await;
    assert!(matches!(child_cmd_rx.try_recv(), Ok(SessionCommand::Cancel(_))));
    assert!(matches!(
            child_cmd_rx.try_recv(),
            Ok(SessionCommand::Shutdown(_))
        ));
    assert!(result.is_interrupted());
}
/// A pending cancel removes a freshly-created worktree but preserves a resumed child worktree owned by its source.
#[tokio::test]
async fn cancel_pending_at_promote_removes_fresh_worktree_preserves_resumed() {
    xai_test_utils::require_git!();
    use xai_test_utils::git::{git_commit_all, init_git_repo};
    let temp = tempfile::TempDir::new().unwrap();
    let repo = temp.path().join("repo");
    std::fs::create_dir(&repo).unwrap();
    init_git_repo(&repo);
    std::fs::write(repo.join("tracked.txt"), "original").unwrap();
    git_commit_all(&repo, "initial");
    let fresh = temp.path().join("subagent-fresh");
    xai_fast_worktree::WorktreeBuilder::new(&repo, &fresh)
        .standalone(true)
        .create()
        .unwrap();
    assert!(fresh.exists());
    run_promote_cancel_with_worktree(&fresh, true).await;
    assert!(
            !fresh.exists(),
            "freshly-created worktree must be removed on pending-kill"
        );
    let resumed = temp.path().join("subagent-resumed");
    xai_fast_worktree::WorktreeBuilder::new(&repo, &resumed)
        .standalone(true)
        .create()
        .unwrap();
    std::fs::write(resumed.join("tracked.txt"), "source edit").unwrap();
    assert!(resumed.exists());
    run_promote_cancel_with_worktree(&resumed, false).await;
    assert!(
            resumed.exists(),
            "resumed subagent's reused worktree must be preserved (source owns it)"
        );
    assert_eq!(
            std::fs::read_to_string(resumed.join("tracked.txt")).unwrap(),
            "source edit",
            "the source's working state must be left untouched"
        );
}
#[tokio::test]
async fn unproven_thread_exit_preserves_fresh_worktree() {
    let mut ctx = ctx_with_toggle(HashMap::new());
    let fixture = DurableCompletionFixture::new(&mut ctx).await;
    let (child_cmd_tx, mut child_cmd_rx) = mpsc::unbounded_channel();
    let mut request = auto_wake_test_request("unproven-exit");
    request.parent_session_id = ctx.parent_session_id.clone();
    let meta_dir = fixture.directory.path().join("subagents").join(&request.id);
    let worktree = tempfile::tempdir().expect("worktree");
    let (hold_tx, hold_rx) = std::sync::mpsc::channel::<()>();
    let thread = SessionThread::from_handle(
        std::thread::spawn(move || {
            let _ = hold_rx.recv();
        }),
    );
    let completion_data = pending_shell_completion_fixture(&ctx, xai_chat_state::SubagentCompletionId {
        subagent_id: request.id.clone(),
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
    }, &meta_dir);
    let initial_metadata = std::fs::read(meta_dir.join("meta.json")).expect("initial metadata");
    let result = cancel_pending_shell_child(
            &child_cmd_tx,
            thread,
            &ctx.workspace_ops,
            &request.id,
            &acp::SessionId::new(request.id.clone()),
            &meta_dir,
            Some(worktree.path()),
            true,
            42,
            &test_gcs_context(&ctx),
            std::time::Duration::ZERO,
            UnpromotedChildDisposition::Cancelled,
            true,
            &completion_data,
        )
        .await;
    assert!(matches!(child_cmd_rx.try_recv(), Ok(SessionCommand::Cancel(_))));
    assert!(matches!(
            child_cmd_rx.try_recv(),
            Ok(SessionCommand::Shutdown(_))
        ));
    assert!(result.is_interrupted());
    assert!(
            worktree.path().exists(),
            "worktree must stay when actor exit is not proven"
        );
    assert_eq!(std::fs::read(meta_dir.join("meta.json")).unwrap(), initial_metadata);
    let completion = ChildCompletion {
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
        snapshot: test_snapshot(&request, &result),
        request,
        result,
        completion_data,
        disposition: CompletionDisposition {
            foreground_delivered: false,
            backgrounded: false,
            waiter_delivered: false,
            explicitly_killed: false,
            reporting: xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Silent,
        },
    };
    let initial: SubagentMeta = serde_json::from_slice(&initial_metadata).unwrap();
    assert_eq!(initial.status, SubagentMetaStatus::Running);
    assert!(initial.completed_at.is_none());
    let before_commit = fixture.storage.load_session(&fixture.info).await.expect("history before producer commit");
    assert!(!before_commit.updates.iter().any(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification)
            if matches!(notification.update, SessionUpdate::SubagentFinished { .. }))));
    prepare_completion_admission(&completion).await.expect("actual producer commit");
    let producer = completion.completion_data.prepared_producer().expect("actual producer acknowledgement");
    assert_eq!(producer.event.state, SubagentState::Interrupted {
        cause: InterruptionCause::Error { message: "Subagent was cancelled".into() },
    });
    let committed_data = std::fs::read(meta_dir.join("meta.json")).unwrap();
    let committed: SubagentMeta = serde_json::from_slice(&committed_data).unwrap();
    let expected_terminal = SubagentMeta {
        status: SubagentMetaStatus::Cancelled,
        completed_at: Some(producer.event.completed_at),
        duration_ms: Some(42),
        tool_calls: Some(0),
        turns: Some(0),
        error: Some("Subagent was cancelled".into()),
        ..initial
    };
    assert_eq!(serde_json::to_value(&committed).unwrap(), serde_json::to_value(&expected_terminal).unwrap());
    assert!(committed.snapshot_ref.is_none());
    assert!(worktree.path().exists(), "producer acknowledgement must not release an unproven worker's worktree");
    let after_commit = fixture.storage.load_session(&fixture.info).await.expect("history after producer acknowledgement");
    assert!(!after_commit.updates.iter().any(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification)
            if matches!(notification.update, SessionUpdate::SubagentFinished { .. }))));
    let (gateway, _gateway_rx) = test_gateway_with_receiver();
    assert!(matches!(
        publish_committed_completion(completion.clone(), gateway.clone()).await,
        xai_grok_tools::implementations::grok_build::task::coordinator::TerminalVisibilityResult::Published
    ));
    assert_eq!(std::fs::read(meta_dir.join("meta.json")).unwrap(), committed_data);
    let meta: SubagentMeta = serde_json::from_str(
            &std::fs::read_to_string(meta_dir.join("meta.json"))
                .expect("read meta"),
        )
        .expect("parse meta");
    assert_eq!(meta.status, SubagentMetaStatus::Cancelled);
    assert!(meta.completed_at.is_some());
    assert_eq!(meta.error.as_deref(), Some("Subagent was cancelled"));
    assert!(worktree.path().exists(), "committing the outcome must not release an unproven worker's worktree");
    assert!(matches!(
        publish_committed_completion(completion, gateway).await,
        xai_grok_tools::implementations::grok_build::task::coordinator::TerminalVisibilityResult::Published
    ));
    assert_eq!(std::fs::read(meta_dir.join("meta.json")).unwrap(), committed_data);
    assert!(worktree.path().exists(), "publication replay must not release an unproven worker's worktree");
    let repeated: SubagentMeta = serde_json::from_slice(&std::fs::read(meta_dir.join("meta.json")).unwrap()).unwrap();
    assert_eq!(serde_json::to_value(&repeated).unwrap(), serde_json::to_value(&meta).unwrap());
    let persisted = fixture.storage.load_session(&fixture.info).await.expect("actual persisted lifecycle");
    assert_eq!(persisted.updates.iter().filter(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification) if matches!(&notification.update,
            SessionUpdate::SubagentFinished { subagent_id, status, .. } if subagent_id == "unproven-exit" && status == "cancelled"))).count(), 1);
    drop(hold_tx);
}
#[tokio::test]
async fn startup_admission_timeout_is_failed_not_cancelled() {
    let mut ctx = ctx_with_toggle(HashMap::new());
    let fixture = DurableCompletionFixture::new(&mut ctx).await;
    let (child_cmd_tx, mut child_cmd_rx) = mpsc::unbounded_channel();
    let (gateway, mut gateway_rx) = test_gateway_with_receiver();
    let mut request = auto_wake_test_request("promote-timeout");
    request.parent_session_id = ctx.parent_session_id.clone();
    let meta_dir = fixture.directory.path().join("subagents").join(&request.id);
    let completion_data = pending_shell_completion_fixture(&ctx, xai_chat_state::SubagentCompletionId {
        subagent_id: request.id.clone(),
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
    }, &meta_dir);
    let initial_metadata = std::fs::read(meta_dir.join("meta.json")).expect("initial metadata");
    let result = cancel_pending_shell_child(
            &child_cmd_tx,
            SessionThread::from_handle(std::thread::spawn(|| {})),
            &ctx.workspace_ops,
            &request.id,
            &acp::SessionId::new(request.id.clone()),
            &meta_dir,
            None,
            false,
            42,
            &test_gcs_context(&ctx),
            UNPROMOTED_SESSION_THREAD_EXIT_TIMEOUT,
            UnpromotedChildDisposition::AdmissionTimedOut,
            true,
            &completion_data,
        )
        .await;
    assert!(matches!(child_cmd_rx.try_recv(), Ok(SessionCommand::Cancel(_))));
    assert!(matches!(
            child_cmd_rx.try_recv(),
            Ok(SessionCommand::Shutdown(_))
        ));
    assert!(!result.is_interrupted());
    assert!(!result.success());
    assert_eq!(result.status(), "failed");
    assert_eq!(
            result.error().as_deref(),
            Some("Subagent initial prompt was not admitted before the deadline")
        );
    assert_eq!(std::fs::read(meta_dir.join("meta.json")).unwrap(), initial_metadata);
    completion_data.mark_spawned_notification_emitted();
    let completion = ChildCompletion {
        attempt_id: xai_message_delivery_core::AttemptId::mint(1),
        snapshot: test_snapshot(&request, &result),
        request,
        result,
        completion_data,
        disposition: CompletionDisposition {
            foreground_delivered: false,
            backgrounded: false,
            waiter_delivered: false,
            explicitly_killed: false,
            reporting: xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Silent,
        },
    };
    let will_wake = will_wake_for(&completion);
    assert!(!will_wake);
    let initial: SubagentMeta = serde_json::from_slice(&initial_metadata).unwrap();
    assert_eq!(initial.status, SubagentMetaStatus::Running);
    assert!(initial.completed_at.is_none());
    let before_commit = fixture.storage.load_session(&fixture.info).await.expect("history before producer commit");
    assert!(!before_commit.updates.iter().any(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification)
            if matches!(notification.update, SessionUpdate::SubagentFinished { .. }))));
    prepare_completion_admission(&completion).await.expect("actual producer commit");
    let producer = completion.completion_data.prepared_producer().expect("actual producer acknowledgement");
    assert_eq!(producer.event.state, SubagentState::Failed {
        message: "Subagent initial prompt was not admitted before the deadline".into(),
    });
    let committed_data = std::fs::read(meta_dir.join("meta.json")).unwrap();
    let committed: SubagentMeta = serde_json::from_slice(&committed_data).unwrap();
    let expected_terminal = SubagentMeta {
        status: SubagentMetaStatus::Failed,
        completed_at: Some(producer.event.completed_at),
        duration_ms: Some(42),
        tool_calls: Some(0),
        turns: Some(0),
        error: Some("Subagent initial prompt was not admitted before the deadline".into()),
        ..initial
    };
    assert_eq!(serde_json::to_value(&committed).unwrap(), serde_json::to_value(&expected_terminal).unwrap());
    assert!(committed.snapshot_ref.is_none());
    let after_commit = fixture.storage.load_session(&fixture.info).await.expect("history after producer acknowledgement");
    assert!(!after_commit.updates.iter().any(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification)
            if matches!(notification.update, SessionUpdate::SubagentFinished { .. }))));
    assert!(matches!(
        publish_committed_completion(completion.clone(), gateway.clone()).await,
        xai_grok_tools::implementations::grok_build::task::coordinator::TerminalVisibilityResult::Published
    ));
    assert_eq!(std::fs::read(meta_dir.join("meta.json")).unwrap(), committed_data);
    let meta: SubagentMeta = serde_json::from_str(
            &std::fs::read_to_string(meta_dir.join("meta.json"))
                .expect("read meta"),
        )
        .expect("parse meta");
    assert_eq!(meta.status, SubagentMetaStatus::Failed);
    assert!(meta.completed_at.is_some());
    assert_eq!(meta.error.as_deref(), Some("Subagent initial prompt was not admitted before the deadline"));
    let updates = fixture.storage.load_session(&fixture.info).await.expect("actual persisted lifecycle").updates;
    let persisted = updates.iter().filter(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification) if matches!(&notification.update,
            SessionUpdate::SubagentFinished { subagent_id, status, .. } if subagent_id == "promote-timeout" && status == "failed"))).count();
    assert_eq!(persisted, 1);
    assert!(matches!(
        publish_committed_completion(completion, gateway.clone()).await,
        xai_grok_tools::implementations::grok_build::task::coordinator::TerminalVisibilityResult::Published
    ));
    gateway.forward_fire_and_forget(acp::ExtNotification::new(
        "fixture/deadline-replay-fifo",
        serde_json::value::to_raw_value(&serde_json::Value::Null).unwrap().into(),
    ));
    let live = tokio::time::timeout(std::time::Duration::from_secs(5), async {
        let mut notifications = Vec::new();
        loop {
            let message = gateway_rx.recv().await.expect("complete replay gateway FIFO");
            if let xai_acp_lib::AcpClientMessage::ExtNotification(args) = message {
                if args.request.method.as_ref() == "fixture/deadline-replay-fifo" { break; }
                let notification: SessionNotification = serde_json::from_str(args.request.params.get()).unwrap();
                if matches!(&notification.update, SessionUpdate::SubagentFinished { subagent_id, .. }
                    if subagent_id == "promote-timeout") { notifications.push(notification); }
            }
        }
        notifications
    }).await.expect("whole replay observation");
    // Raw delivery is at-least-once; the real AppView replay test owns visible exactly-once.
    assert!(live.len() > 1, "the repeated publisher must actually reach the consumer transport");
    for notification in &live {
        assert!(matches!(&notification.update, SessionUpdate::SubagentFinished { status, error, .. }
            if status == "failed" && error.as_deref() == Some("Subagent initial prompt was not admitted before the deadline")));
        assert_eq!(notification.meta.as_ref().unwrap()["eventId"], live[0].meta.as_ref().unwrap()["eventId"]);
    }
    assert_eq!(std::fs::read(meta_dir.join("meta.json")).unwrap(), committed_data);
    let repeated: SubagentMeta = serde_json::from_slice(&std::fs::read(meta_dir.join("meta.json")).unwrap()).unwrap();
    assert_eq!(serde_json::to_value(&repeated).unwrap(), serde_json::to_value(&meta).unwrap());
    let updates = fixture.storage.load_session(&fixture.info).await.expect("replayed persisted lifecycle").updates;
    assert_eq!(updates.iter().filter(|update| matches!(update,
        crate::session::storage::SessionUpdate::Xai(notification) if matches!(&notification.update,
            SessionUpdate::SubagentFinished { subagent_id, .. } if subagent_id == "promote-timeout"))).count(), 1);
}
fn test_model_entry(model_id: &str) -> crate::agent::config::ModelEntry {
    crate::agent::config::ModelEntry {
        info: crate::agent::config::ModelInfo {
            model: model_id.to_string(),
            context_window: std::num::NonZeroU64::new(256_000).unwrap(),
            ..Default::default()
        },
        mtls_cert_dir: None,
        api_key: None,
        env_key: None,
        auth_provider: None,
        api_base_url: None,
    }
}
fn byok_model_entry(model_id: &str) -> crate::agent::config::ModelEntry {
    crate::agent::config::ModelEntry {
        api_key: Some("byok-key".to_string()),
        ..test_model_entry(model_id)
    }
}
#[test]
fn subagent_auth_type_rule() {
    use crate::agent::auth_method::{CACHED_TOKEN_AUTH_METHOD_ID, XAI_API_KEY_METHOD_ID};
    use xai_chat_state::AuthType;
    let session = acp::AuthMethodId::new(CACHED_TOKEN_AUTH_METHOD_ID);
    let api_key = acp::AuthMethodId::new(XAI_API_KEY_METHOD_ID);
    let byok = byok_model_entry("grok-byok");
    let plain = test_model_entry("grok-plain");
    assert_eq!(
            super::subagent_auth_type(Some(&byok), &session),
            AuthType::ApiKey
        );
    assert_eq!(
            super::subagent_auth_type(Some(&byok), &api_key),
            AuthType::ApiKey
        );
    assert_eq!(
            super::subagent_auth_type(Some(&plain), &session),
            AuthType::SessionToken,
        );
    assert_eq!(
            super::subagent_auth_type(Some(&plain), &api_key),
            AuthType::ApiKey
        );
    assert_eq!(
            super::subagent_auth_type(None, &session),
            AuthType::SessionToken
        );
    assert_eq!(super::subagent_auth_type(None, &api_key), AuthType::ApiKey);
}
const SELECTABLE_TOOL: ModelOverrideProvenance = ModelOverrideProvenance::Tool {
    selection: TaskModelSelection::Selectable,
};
#[test]
fn fresh_tool_model_accepts_visible_key_and_internal_id() {
    let mut models = indexmap::IndexMap::new();
    models.insert("grok-3".to_string(), test_model_entry("grok-3-2025-02-15"));
    assert!(
            admit_explicit_tool_model(
                "grok-3",
                TaskModelSelection::Selectable,
                &models,
                false,
            )
            .is_ok(),
            "key lookup should succeed"
        );
    assert!(
            admit_explicit_tool_model(
                "grok-3-2025-02-15",
                TaskModelSelection::Selectable,
                &models,
                false,
            )
            .is_ok(),
            "info().model lookup should succeed"
        );
    assert_eq!(
            admit_explicit_tool_model("grok-3", TaskModelSelection::Inherited, &models, false),
            Err(TaskModelAdmissionError::HiddenSelection),
        );
}
#[test]
fn fresh_tool_model_rejects_unavailable_exact_key_over_visible_slug_collision() {
    let mut models = indexmap::IndexMap::new();
    models.insert("visible-alias".to_string(), test_model_entry("collision"));
    let mut unavailable_exact = test_model_entry("hidden-internal");
    unavailable_exact.info.hidden = true;
    models.insert("collision".to_string(), unavailable_exact);
    assert_eq!(
            admit_explicit_tool_model(
                "collision",
                TaskModelSelection::Selectable,
                &models,
                false,
            ),
            Err(TaskModelAdmissionError::Unavailable(
                "Unknown Task.model slug 'collision'. Valid model slugs: visible-alias. \
                 Omit `model` to inherit the parent model."
                    .to_string()
            )),
            "validation must inspect the unavailable exact-key entry selected by execution"
        );
}
#[test]
fn fresh_tool_model_rejects_unavailable_first_slug_collision() {
    let mut models = indexmap::IndexMap::new();
    let mut unavailable_first = test_model_entry("shared-routing-slug");
    unavailable_first.info.user_selectable = false;
    models.insert("blocked-first".to_string(), unavailable_first);
    models.insert("visible-second".to_string(), test_model_entry("shared-routing-slug"));
    assert_eq!(
            admit_explicit_tool_model(
                "shared-routing-slug",
                TaskModelSelection::Selectable,
                &models,
                false,
            ),
            Err(TaskModelAdmissionError::Unavailable(
                "Unknown Task.model slug 'shared-routing-slug'. Valid model slugs: \
                 visible-second. Omit `model` to inherit the parent model."
                    .to_string()
            )),
            "validation must inspect the first routing-slug entry selected by execution"
        );
}
#[test]
fn fresh_tool_model_rejects_unknown_and_nonavailable_entries() {
    let mut models = indexmap::IndexMap::new();
    models.insert("zeta".to_string(), test_model_entry("zeta-internal"));
    let mut hidden = test_model_entry("hidden-internal");
    hidden.info.hidden = true;
    models.insert("hidden".to_string(), hidden);
    let mut not_selectable = test_model_entry("disabled-internal");
    not_selectable.info.user_selectable = false;
    models.insert("disabled".to_string(), not_selectable);
    let mut oauth_only = test_model_entry("oauth-only-internal");
    oauth_only.info.supported_in_api = false;
    models.insert("oauth-only".to_string(), oauth_only);
    models.insert("alpha".to_string(), test_model_entry("alpha-internal"));
    for requested in [
        "stale-model",
        "hidden",
        "hidden-internal",
        "disabled",
        "disabled-internal",
        "oauth-only",
        "oauth-only-internal",
    ] {
        let error = admit_explicit_tool_model(
                requested,
                TaskModelSelection::Selectable,
                &models,
                false,
            )
            .unwrap_err();
        assert_eq!(
                error,
                TaskModelAdmissionError::Unavailable(format!(
                    "Unknown Task.model slug '{requested}'. Valid model slugs: alpha, zeta. \
                     Omit `model` to inherit the parent model."
                ))
            );
    }
    assert!(
            admit_explicit_tool_model(
                "oauth-only",
                TaskModelSelection::Selectable,
                &models,
                true,
            )
            .is_ok(),
            "OAuth-only model should resolve for session auth"
        );
}
#[test]
fn resumed_tool_model_override_is_ignored() {
    let overrides = SubagentRuntimeOverrides {
        model: Some("stale-model".to_string()),
        model_override_provenance: SELECTABLE_TOOL,
        ..Default::default()
    };
    assert!(
            explicit_tool_model(&overrides, true).is_none(),
            "resume must preserve source-model pinning"
        );
}
#[test]
fn harness_model_override_keeps_internal_fallback_behavior() {
    let overrides = SubagentRuntimeOverrides {
        model: Some("internal-model".to_string()),
        model_override_provenance: ModelOverrideProvenance::Harness,
        ..Default::default()
    };
    assert!(
            explicit_tool_model(&overrides, false).is_none(),
            "internal role/config pins must retain downstream soft fallback"
        );
}
#[test]
fn normalize_forked_context_empty_parent() {
    use xai_grok_sampling_types::conversation::ConversationItem;
    let items = vec![ConversationItem::system("sys prompt")];
    let (conv, prefix_len) = xai_grok_subagent_resolution::context::normalize_forked_context(
        items,
    );
    assert_eq!(conv.len(), 1);
    assert_eq!(prefix_len, 1);
    assert!(matches!(conv.first(), Some(ConversationItem::System(_))));
}
fn test_sampling_config(model_slug: &str) -> xai_grok_sampling_types::SamplingConfig {
    use std::num::NonZeroU64;
    xai_grok_sampling_types::SamplingConfig {
        base_url: "https://api.test/v1".to_string(),
        model: model_slug.to_string(),
        context_window: NonZeroU64::new(256_000).expect("non-zero context window"),
        ..Default::default()
    }
}
fn spawn_test_parent_chat_state(model_slug: &str) -> xai_chat_state::ChatStateHandle {
    let (mock, _persistence_rx) = xai_chat_state::MockChatPersistence::new();
    let (event_tx, _event_rx) = mpsc::unbounded_channel();
    let token = tokio_util::sync::CancellationToken::new();
    xai_chat_state::ChatStateActor::spawn(
        vec![],
        test_sampling_config(model_slug),
        Box::new(mock),
        event_tx,
        token,
    )
}
mod rest;
mod resume;
mod wake;
#[tokio::test]
async fn panicked_announced_foreground_child_emits_one_typed_finish() {
    let (gateway, _gateway_rx) = test_gateway_with_receiver();
    let (parent_cmd_tx, mut parent_cmd_rx) = mpsc::unbounded_channel();
    let mut request = auto_wake_test_request("panic-after-spawn");
    request.run_in_background = false;
    let completion_data = ShellCompletionData {
        parent_cmd_tx: Some(parent_cmd_tx),
        ..Default::default()
    };
    let worker_completion_data = completion_data.clone();
    let inner = super::worker_runtime()
        .expect("worker runtime")
        .spawn(async move {
            worker_completion_data.mark_spawned_notification_emitted();
            panic!("worker boom");
        });
    let output = join_worker_task(
            inner,
            ChildRunOutput {
                result: SubagentResult {
                    state: SubagentState::Failed { message: "Subagent runtime panicked".to_owned() },
                    subagent_id: request.id.clone(),
                    child_session_id: request.id.clone(),
                    ..Default::default()
                },
                completion_data,
                snapshot_ref: None,
            },
        )
        .await;
    let snapshot = test_snapshot(&request, &output.result);
    present_child_completion(
        ChildCompletion {
            attempt_id: xai_message_delivery_core::AttemptId::mint(0xface),
            snapshot,
            request,
            result: output.result,
            completion_data: output.completion_data,
            disposition: CompletionDisposition {
                foreground_delivered: true,
                backgrounded: false,
                waiter_delivered: false,
                explicitly_killed: false,
                reporting: xai_grok_tools::implementations::grok_build::task::coordinator::CompletionReporting::Silent,
            },
        },
        &gateway,
        false,
    );
    let finishes = std::iter::from_fn(|| parent_cmd_rx.try_recv().ok())
        .filter_map(|command| match command {
            SessionCommand::SubagentCompletionPublished {
                notification: SessionNotification {
                    update: SessionUpdate::SubagentFinished { attempt_id, .. },
                    ..
                },
            } => Some(attempt_id),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(finishes, vec![Some("at1.face".to_owned())]);
}
#[tokio::test]
async fn join_worker_task_drop_aborts_worker() {
    struct SendOnDrop(Option<tokio::sync::oneshot::Sender<()>>);
    impl Drop for SendOnDrop {
        fn drop(&mut self) {
            if let Some(tx) = self.0.take() {
                let _ = tx.send(());
            }
        }
    }
    let (dropped_tx, dropped_rx) = tokio::sync::oneshot::channel();
    let (started_tx, started_rx) = tokio::sync::oneshot::channel();
    let inner = super::worker_runtime()
        .expect("worker runtime")
        .spawn(async move {
            let _probe = SendOnDrop(Some(dropped_tx));
            let _ = started_tx.send(());
            std::future::pending::<()>().await;
        });
    started_rx.await.expect("worker started");
    let mut fut = Box::pin(join_worker_task(inner, ()));
    let mut cx = std::task::Context::from_waker(std::task::Waker::noop());
    assert!(
            std::future::Future::poll(fut.as_mut(), &mut cx).is_pending(),
            "worker is pending until aborted"
        );
    drop(fut);
    tokio::time::timeout(std::time::Duration::from_secs(5), dropped_rx)
        .await
        .expect("abort must reach the worker task")
        .expect("drop probe fires on abort");
}
